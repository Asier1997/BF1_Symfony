<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/armasclases')) {
            // armasclases_index
            if (rtrim($pathinfo, '/') === '/armasclases') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasclases_index;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'armasclases_index');
                }

                return array (  '_controller' => 'AppBundle\\Controller\\ArmasClasesController::indexAction',  '_route' => 'armasclases_index',);
            }
            not_armasclases_index:

            // armasclases_new
            if ($pathinfo === '/armasclases/new') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_armasclases_new;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\ArmasClasesController::newAction',  '_route' => 'armasclases_new',);
            }
            not_armasclases_new:

            // armasclases_show
            if (preg_match('#^/armasclases/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasclases_show;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasclases_show')), array (  '_controller' => 'AppBundle\\Controller\\ArmasClasesController::showAction',));
            }
            not_armasclases_show:

            // armasclases_edit
            if (preg_match('#^/armasclases/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_armasclases_edit;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasclases_edit')), array (  '_controller' => 'AppBundle\\Controller\\ArmasClasesController::editAction',));
            }
            not_armasclases_edit:

            // armasclases_delete
            if (preg_match('#^/armasclases/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'DELETE') {
                    $allow[] = 'DELETE';
                    goto not_armasclases_delete;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasclases_delete')), array (  '_controller' => 'AppBundle\\Controller\\ArmasClasesController::deleteAction',));
            }
            not_armasclases_delete:

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // inicio
        if ($pathinfo === '/inicio') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::inicioAction',  '_route' => 'inicio',);
        }

        if (0 === strpos($pathinfo, '/a')) {
            // asalto
            if ($pathinfo === '/asalto') {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::asaltoAction',  '_route' => 'asalto',);
            }

            // apoyo
            if ($pathinfo === '/apoyo') {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::apoyoAction',  '_route' => 'apoyo',);
            }

        }

        // medico
        if ($pathinfo === '/medico') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::medicoAction',  '_route' => 'medico',);
        }

        // explorador
        if ($pathinfo === '/explorador') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::exploradorAction',  '_route' => 'explorador',);
        }

        // vehiculos
        if ($pathinfo === '/vehiculos') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::vehiculosAction',  '_route' => 'vehiculos',);
        }

        if (0 === strpos($pathinfo, '/armas')) {
            // armasarasasalto
            if ($pathinfo === '/armasasalto') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasarasasalto;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::armasasaltoAction',  '_route' => 'armasarasasalto',);
            }
            not_armasarasasalto:

            // armasarmedico
            if ($pathinfo === '/armasmedico') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasarmedico;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::armasamedicoAction',  '_route' => 'armasarmedico',);
            }
            not_armasarmedico:

            // armasarapoyo
            if ($pathinfo === '/armasapoyo') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasarapoyo;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::armasapoyoAction',  '_route' => 'armasarapoyo',);
            }
            not_armasarapoyo:

            // armasaexplorador
            if ($pathinfo === '/armasexplorador') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_armasaexplorador;
                }

                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::armasaexploradorAction',  '_route' => 'armasaexplorador',);
            }
            not_armasaexplorador:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}

<?php

/* Explorador/Explorador.html.twig */
class __TwigTemplate_f7c515664c0e636514788f67f34a8eec4f65a314216717a12859bdf02d42d92b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Explorador/Explorador.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c24f23d64e685bdc43064830305bcfb55d8adae18ee77fd0e202857c469e06f8 = $this->env->getExtension("native_profiler");
        $__internal_c24f23d64e685bdc43064830305bcfb55d8adae18ee77fd0e202857c469e06f8->enter($__internal_c24f23d64e685bdc43064830305bcfb55d8adae18ee77fd0e202857c469e06f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Explorador/Explorador.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c24f23d64e685bdc43064830305bcfb55d8adae18ee77fd0e202857c469e06f8->leave($__internal_c24f23d64e685bdc43064830305bcfb55d8adae18ee77fd0e202857c469e06f8_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0f14897b96a1306a7e528f596f8dd93e5725f73904d5a1c1c21dad2f76f4a4f6 = $this->env->getExtension("native_profiler");
        $__internal_0f14897b96a1306a7e528f596f8dd93e5725f73904d5a1c1c21dad2f76f4a4f6->enter($__internal_0f14897b96a1306a7e528f596f8dd93e5725f73904d5a1c1c21dad2f76f4a4f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>Bienvenido a la guia del explorador</br>
<br>El explorador dispone de fusiles de precisión capaces de acabar con enemigos a distancias muy largas sin ni siquiera ellos lo sepan. Sus dispositivos son unas</br>
<br>bengalas, capaces de revelar enemigos en un área, y unos binoculares, que pueden detectar enemigos a distancias muy largas.</br>
<br></br>
<br>Como explorador, deberías de estar lejos de la acción ayudando a tus compañeros acabando con objetivos clave. También no te olvides de usar los binoculares y</br>
<br>las bengalas, esto dará mucha información a tu equipo.</br>

<img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Explorador_edit.jpg"), "html", null, true);
        echo "\" width=30% />
";
        
        $__internal_0f14897b96a1306a7e528f596f8dd93e5725f73904d5a1c1c21dad2f76f4a4f6->leave($__internal_0f14897b96a1306a7e528f596f8dd93e5725f73904d5a1c1c21dad2f76f4a4f6_prof);

    }

    public function getTemplateName()
    {
        return "Explorador/Explorador.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 11,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>Bienvenido a la guia del explorador</br>*/
/* <br>El explorador dispone de fusiles de precisión capaces de acabar con enemigos a distancias muy largas sin ni siquiera ellos lo sepan. Sus dispositivos son unas</br>*/
/* <br>bengalas, capaces de revelar enemigos en un área, y unos binoculares, que pueden detectar enemigos a distancias muy largas.</br>*/
/* <br></br>*/
/* <br>Como explorador, deberías de estar lejos de la acción ayudando a tus compañeros acabando con objetivos clave. También no te olvides de usar los binoculares y</br>*/
/* <br>las bengalas, esto dará mucha información a tu equipo.</br>*/
/* */
/* <img src="{{asset('build/images/Explorador_edit.jpg')}}" width=30% />*/
/* {% endblock %}*/

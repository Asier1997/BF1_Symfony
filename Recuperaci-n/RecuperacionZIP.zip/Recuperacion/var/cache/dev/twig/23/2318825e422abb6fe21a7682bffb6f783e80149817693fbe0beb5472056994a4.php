<?php

/* Inicio/Inicio.html.twig */
class __TwigTemplate_fd2e01e7979c64f8264716e08a8114ec3c15d6b4cd9d5cd853ccacd0ad76f53c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Inicio/Inicio.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ec0bab8ca39ea7f69167a21d666f777749757f03c6a1fbec34d2046ed3319e5 = $this->env->getExtension("native_profiler");
        $__internal_2ec0bab8ca39ea7f69167a21d666f777749757f03c6a1fbec34d2046ed3319e5->enter($__internal_2ec0bab8ca39ea7f69167a21d666f777749757f03c6a1fbec34d2046ed3319e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Inicio/Inicio.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2ec0bab8ca39ea7f69167a21d666f777749757f03c6a1fbec34d2046ed3319e5->leave($__internal_2ec0bab8ca39ea7f69167a21d666f777749757f03c6a1fbec34d2046ed3319e5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8d6a940d311c8eda7d640080f3bf002d2c349fc004ac3befa94fe36741208dbd = $this->env->getExtension("native_profiler");
        $__internal_8d6a940d311c8eda7d640080f3bf002d2c349fc004ac3befa94fe36741208dbd->enter($__internal_8d6a940d311c8eda7d640080f3bf002d2c349fc004ac3befa94fe36741208dbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>Bienvenido!</br>
<br>En esta página encontraras guías básicas de cómo funcionan las clases y los vehículos en Battlefield 1, así tendrás unas nociones básicas de cómo funciona el juego.</br>
";
        
        $__internal_8d6a940d311c8eda7d640080f3bf002d2c349fc004ac3befa94fe36741208dbd->leave($__internal_8d6a940d311c8eda7d640080f3bf002d2c349fc004ac3befa94fe36741208dbd_prof);

    }

    public function getTemplateName()
    {
        return "Inicio/Inicio.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>Bienvenido!</br>*/
/* <br>En esta página encontraras guías básicas de cómo funcionan las clases y los vehículos en Battlefield 1, así tendrás unas nociones básicas de cómo funciona el juego.</br>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */

<?php

/* Apoyo/Apoyo.html.twig */
class __TwigTemplate_ff7ccfcf2c76b9b63e75b7d59d922d388a5eca3c97967950a158d410e827dc7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Apoyo/Apoyo.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89c0a52ed434182bea4110cf1a1cc5f65e6645b203a14f2fdf02fe0ee82ed5e1 = $this->env->getExtension("native_profiler");
        $__internal_89c0a52ed434182bea4110cf1a1cc5f65e6645b203a14f2fdf02fe0ee82ed5e1->enter($__internal_89c0a52ed434182bea4110cf1a1cc5f65e6645b203a14f2fdf02fe0ee82ed5e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Apoyo/Apoyo.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_89c0a52ed434182bea4110cf1a1cc5f65e6645b203a14f2fdf02fe0ee82ed5e1->leave($__internal_89c0a52ed434182bea4110cf1a1cc5f65e6645b203a14f2fdf02fe0ee82ed5e1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3d4d73638a9724fd99626a7b6e5778a2311b60aefba8f8570e83c5892676efd5 = $this->env->getExtension("native_profiler");
        $__internal_3d4d73638a9724fd99626a7b6e5778a2311b60aefba8f8570e83c5892676efd5->enter($__internal_3d4d73638a9724fd99626a7b6e5778a2311b60aefba8f8570e83c5892676efd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>Bienvenido a la guia del apoyo.</br>
<br>El Apoyo tiene ametralladoras ligeras que son muy efectivas en contener grupos de enemigos, y más aún si están a medio alcance. La función principal</br>
<br>de esta clase, es la de proporcionar munición y ayudar a la hora de destruir tanques enemigos. Para esto, el Apoyo dispone de cajas de munición y cargas</br>
<br>antitanque.</br>
<br></br>
<br>La estrategia que deberías llevar, es la de intentar estar cerca de de los asalto aliados, que son los que más munición suelen necesitar, ya que gastaran</br>
<br>sus dispositivos más a menudo que los demás. Con tu ametralladora podras ofrecer apoyo cercano a los soldados de asalto que necesiten acercarse para</br>
<br>hacer daño</br>
<img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Apoyo_edit.jpg"), "html", null, true);
        echo "\"/>
";
        
        $__internal_3d4d73638a9724fd99626a7b6e5778a2311b60aefba8f8570e83c5892676efd5->leave($__internal_3d4d73638a9724fd99626a7b6e5778a2311b60aefba8f8570e83c5892676efd5_prof);

    }

    public function getTemplateName()
    {
        return "Apoyo/Apoyo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 12,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>Bienvenido a la guia del apoyo.</br>*/
/* <br>El Apoyo tiene ametralladoras ligeras que son muy efectivas en contener grupos de enemigos, y más aún si están a medio alcance. La función principal</br>*/
/* <br>de esta clase, es la de proporcionar munición y ayudar a la hora de destruir tanques enemigos. Para esto, el Apoyo dispone de cajas de munición y cargas</br>*/
/* <br>antitanque.</br>*/
/* <br></br>*/
/* <br>La estrategia que deberías llevar, es la de intentar estar cerca de de los asalto aliados, que son los que más munición suelen necesitar, ya que gastaran</br>*/
/* <br>sus dispositivos más a menudo que los demás. Con tu ametralladora podras ofrecer apoyo cercano a los soldados de asalto que necesiten acercarse para</br>*/
/* <br>hacer daño</br>*/
/* <img src="{{asset('build/images/Apoyo_edit.jpg')}}"/>*/
/* {% endblock %}*/

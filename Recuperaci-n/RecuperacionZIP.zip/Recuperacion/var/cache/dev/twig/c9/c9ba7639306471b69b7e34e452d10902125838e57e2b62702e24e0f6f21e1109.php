<?php

/* armasclases/show.html.twig */
class __TwigTemplate_45479a3c7f0f5334a516bb893382ab55983f1b7c259728b924f7d2a8413bd470 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasclases/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31d72f8b7790356d55ea6aac1e3ecf1888ad1db08aa1c2c2075a04b8a288e6db = $this->env->getExtension("native_profiler");
        $__internal_31d72f8b7790356d55ea6aac1e3ecf1888ad1db08aa1c2c2075a04b8a288e6db->enter($__internal_31d72f8b7790356d55ea6aac1e3ecf1888ad1db08aa1c2c2075a04b8a288e6db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasclases/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_31d72f8b7790356d55ea6aac1e3ecf1888ad1db08aa1c2c2075a04b8a288e6db->leave($__internal_31d72f8b7790356d55ea6aac1e3ecf1888ad1db08aa1c2c2075a04b8a288e6db_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_526db5d07f50ca69f1ee16cdd7c82837495bf0f7406fe33e26607021a9380cea = $this->env->getExtension("native_profiler");
        $__internal_526db5d07f50ca69f1ee16cdd7c82837495bf0f7406fe33e26607021a9380cea->enter($__internal_526db5d07f50ca69f1ee16cdd7c82837495bf0f7406fe33e26607021a9380cea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Mostrando Arma seleccionada</h1>

    <table>
        <tbody>
            <tr>
                <th>Arma</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasClase"]) ? $context["armasClase"] : $this->getContext($context, "armasClase")), "arma", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dmg</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasClase"]) ? $context["armasClase"] : $this->getContext($context, "armasClase")), "dmg", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Cargador</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasClase"]) ? $context["armasClase"] : $this->getContext($context, "armasClase")), "cargador", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Clase</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasClase"]) ? $context["armasClase"] : $this->getContext($context, "armasClase")), "clase", array()), "html", null, true);
        echo "</td>
            </tr>          
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("armasclases_index");
        echo "\">Volver a la lista de armas</a>
        </li>
        <li>
            <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasclases_edit", array("id" => $this->getAttribute((isset($context["armasClase"]) ? $context["armasClase"] : $this->getContext($context, "armasClase")), "id", array()))), "html", null, true);
        echo "\">Editar esta arma</a>
        </li>
        <li>
            ";
        // line 35
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 37
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_526db5d07f50ca69f1ee16cdd7c82837495bf0f7406fe33e26607021a9380cea->leave($__internal_526db5d07f50ca69f1ee16cdd7c82837495bf0f7406fe33e26607021a9380cea_prof);

    }

    public function getTemplateName()
    {
        return "armasclases/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  91 => 35,  85 => 32,  79 => 29,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Mostrando Arma seleccionada</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <td>{{ armasClase.arma }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dmg</th>*/
/*                 <td>{{ armasClase.dmg }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Cargador</th>*/
/*                 <td>{{ armasClase.cargador }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Clase</th>*/
/*                 <td>{{ armasClase.clase }}</td>*/
/*             </tr>          */
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasclases_index') }}">Volver a la lista de armas</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('armasclases_edit', { 'id': armasClase.id }) }}">Editar esta arma</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

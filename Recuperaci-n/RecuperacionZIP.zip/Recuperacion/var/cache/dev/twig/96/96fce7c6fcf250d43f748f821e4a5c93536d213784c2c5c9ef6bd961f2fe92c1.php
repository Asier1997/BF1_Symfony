<?php

/* Asalto/Asalto.html.twig */
class __TwigTemplate_1006d1b3f7bbde4419d4e5b4b64db7efd186ef215867c5a199cd059a92669083 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Asalto/Asalto.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1494fe2f0f424461311126425116f0c4d6549a40790fca7eaa9df09fe8a00ef = $this->env->getExtension("native_profiler");
        $__internal_a1494fe2f0f424461311126425116f0c4d6549a40790fca7eaa9df09fe8a00ef->enter($__internal_a1494fe2f0f424461311126425116f0c4d6549a40790fca7eaa9df09fe8a00ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Asalto/Asalto.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a1494fe2f0f424461311126425116f0c4d6549a40790fca7eaa9df09fe8a00ef->leave($__internal_a1494fe2f0f424461311126425116f0c4d6549a40790fca7eaa9df09fe8a00ef_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ffcd6cf5d19c8e17d438708823fd1761ba132ef308d075e578c75987c53a9afa = $this->env->getExtension("native_profiler");
        $__internal_ffcd6cf5d19c8e17d438708823fd1761ba132ef308d075e578c75987c53a9afa->enter($__internal_ffcd6cf5d19c8e17d438708823fd1761ba132ef308d075e578c75987c53a9afa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>Aqui encontraras la guia de la clase de Asalto.</br>

<br>El asalto tiene armas de corto-media alcance, dispone de subfusiles y de escopetas como armas principales. Su función principal es la de ocuparse de los vehículos enemigos y asaltar posiciones enemigas fortificadas</br>
<br>Para esto, utiliza como \"gadget\" unas granadas antitanque, que son muy efectivas a la hora de sacar enemigos cubiertos y destruir tanques, y un rifle antitanque de medio alcance, el cual se puede utilizar para acabar</br>
<br>con la infantería enemiga que está muy lejos o dañar vehículos enemigos.</br>

<br>La estrategia que deberías seguir como Asalto, debería ser la de intentar acercarte a los enemigos lo máximo posible para sacarle el mayor provecho a tus armas y a tus granadas antitanque. Aunque si ves enemigos en</br>
<br>campo abierto, puedes intentar darles con tu rifle antitanque. Pero cuidado, el rifle antitanque tarda bastante en recargar así que mide bien tu disparo.</br>
<br></br>
<img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Asalto_Ingles_Edit.jpg"), "html", null, true);
        echo "\"/>
 
";
        
        $__internal_ffcd6cf5d19c8e17d438708823fd1761ba132ef308d075e578c75987c53a9afa->leave($__internal_ffcd6cf5d19c8e17d438708823fd1761ba132ef308d075e578c75987c53a9afa_prof);

    }

    public function getTemplateName()
    {
        return "Asalto/Asalto.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 13,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>Aqui encontraras la guia de la clase de Asalto.</br>*/
/* */
/* <br>El asalto tiene armas de corto-media alcance, dispone de subfusiles y de escopetas como armas principales. Su función principal es la de ocuparse de los vehículos enemigos y asaltar posiciones enemigas fortificadas</br>*/
/* <br>Para esto, utiliza como "gadget" unas granadas antitanque, que son muy efectivas a la hora de sacar enemigos cubiertos y destruir tanques, y un rifle antitanque de medio alcance, el cual se puede utilizar para acabar</br>*/
/* <br>con la infantería enemiga que está muy lejos o dañar vehículos enemigos.</br>*/
/* */
/* <br>La estrategia que deberías seguir como Asalto, debería ser la de intentar acercarte a los enemigos lo máximo posible para sacarle el mayor provecho a tus armas y a tus granadas antitanque. Aunque si ves enemigos en</br>*/
/* <br>campo abierto, puedes intentar darles con tu rifle antitanque. Pero cuidado, el rifle antitanque tarda bastante en recargar así que mide bien tu disparo.</br>*/
/* <br></br>*/
/* <img src="{{asset('build/images/Asalto_Ingles_Edit.jpg')}}"/>*/
/*  */
/* {% endblock %}*/
/* */

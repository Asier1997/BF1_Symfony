<?php

/* armasclases/edit.html.twig */
class __TwigTemplate_4f9c48a9949448d4d62eb834f096ac6b01b1698b119453fdb3739b9a0431bb99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasclases/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9bd86c8917c29222f958ea7e9bf6c1311e43d5496561a83b0498921d068f5a6 = $this->env->getExtension("native_profiler");
        $__internal_e9bd86c8917c29222f958ea7e9bf6c1311e43d5496561a83b0498921d068f5a6->enter($__internal_e9bd86c8917c29222f958ea7e9bf6c1311e43d5496561a83b0498921d068f5a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasclases/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e9bd86c8917c29222f958ea7e9bf6c1311e43d5496561a83b0498921d068f5a6->leave($__internal_e9bd86c8917c29222f958ea7e9bf6c1311e43d5496561a83b0498921d068f5a6_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_40eba76da5ef7fb58aae0f3b7df596962fdb03fd72bc5db2b27fc69ba12672c3 = $this->env->getExtension("native_profiler");
        $__internal_40eba76da5ef7fb58aae0f3b7df596962fdb03fd72bc5db2b27fc69ba12672c3->enter($__internal_40eba76da5ef7fb58aae0f3b7df596962fdb03fd72bc5db2b27fc69ba12672c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Editando Arma seleccionada</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Editar\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasclases_index");
        echo "\">Volver a la lista</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_40eba76da5ef7fb58aae0f3b7df596962fdb03fd72bc5db2b27fc69ba12672c3->leave($__internal_40eba76da5ef7fb58aae0f3b7df596962fdb03fd72bc5db2b27fc69ba12672c3_prof);

    }

    public function getTemplateName()
    {
        return "armasclases/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Editando Arma seleccionada</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Editar" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasclases_index') }}">Volver a la lista</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

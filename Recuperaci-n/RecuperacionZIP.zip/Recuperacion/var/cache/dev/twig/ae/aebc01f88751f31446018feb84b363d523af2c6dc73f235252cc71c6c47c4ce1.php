<?php

/* Vehiculos/Vehiculos.html.twig */
class __TwigTemplate_9d9453045aabde0bfa3a93203c83eada1363ae14c421fab954fd80a97fcf4d30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Vehiculos/Vehiculos.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'sidebarVehiculos' => array($this, 'block_sidebarVehiculos'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d49ec643e9f27f78b8ea0e4bf67a6d7770158fdf3bccad037b959941df622bf = $this->env->getExtension("native_profiler");
        $__internal_9d49ec643e9f27f78b8ea0e4bf67a6d7770158fdf3bccad037b959941df622bf->enter($__internal_9d49ec643e9f27f78b8ea0e4bf67a6d7770158fdf3bccad037b959941df622bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Vehiculos/Vehiculos.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9d49ec643e9f27f78b8ea0e4bf67a6d7770158fdf3bccad037b959941df622bf->leave($__internal_9d49ec643e9f27f78b8ea0e4bf67a6d7770158fdf3bccad037b959941df622bf_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8cd109a555a321955c58171b56151170c73b3a43bc07112743415bbd807e9ad9 = $this->env->getExtension("native_profiler");
        $__internal_8cd109a555a321955c58171b56151170c73b3a43bc07112743415bbd807e9ad9->enter($__internal_8cd109a555a321955c58171b56151170c73b3a43bc07112743415bbd807e9ad9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>Aquí encontraras una breve descripción de los vehículos que encontraras en el juego</br>
<br>Camión de artillería: Es un vehículos con una torreta montada en la parte de atrás. Tiene mucha potencia de fuego, pero tiene un blindaje ligero que lo</br>
<br>vuelve bastante débil a corto alcance</br>
<br></br>
<br>Tanque de tierra: Un tanque con una potencia de fuego moderado, capaz de defenderse desde todas las direcciones pero muy lento. Es capaz de romper las</br>
<br>líneas enemigos, pero muy vulnerable a emboscadas</br>
<br></br>
<br>Tanque ligero: Un tanque con mucha movilidad pero una potencia de fuego bajo. Sirve para flanquear a los enemigos y pillarlos desprevenidos</br>
<br></br>
";
        
        $__internal_8cd109a555a321955c58171b56151170c73b3a43bc07112743415bbd807e9ad9->leave($__internal_8cd109a555a321955c58171b56151170c73b3a43bc07112743415bbd807e9ad9_prof);

    }

    // line 15
    public function block_sidebarVehiculos($context, array $blocks = array())
    {
        $__internal_0e3345ee67db3f7d3c9c5bb2148d01ace5542cf085e3d55ae9fd9581ccb845ae = $this->env->getExtension("native_profiler");
        $__internal_0e3345ee67db3f7d3c9c5bb2148d01ace5542cf085e3d55ae9fd9581ccb845ae->enter($__internal_0e3345ee67db3f7d3c9c5bb2148d01ace5542cf085e3d55ae9fd9581ccb845ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebarVehiculos"));

        // line 16
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/css/mystile2.css"), "html", null, true);
        echo "\"/>
<div class=\"slideshow-container\">

<div class=\"mySlides fade\">
  <div class=\"numbertext\">1 / 3</div>
  <img src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Artilleria_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Camión de Artillería</div>
</div>

<div class=\"mySlides fade\">
  <div class=\"numbertext\">2 / 3</div>
  <img src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Tierra_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Tanque de tierra</div>
</div>

<div class=\"mySlides fade\">
  <div class=\"numbertext\">3 / 3</div>
  <img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Ligero_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Tanque Ligero</div>
</div>

<a class=\"prev\" onclick=\"plusSlides(-1)\">&#10094;</a>
<a class=\"next\" onclick=\"plusSlides(1)\">&#10095;</a>

</div>
<br>

<div style=\"text-align:center\">
  <span class=\"dot\" onclick=\"currentSlide(1)\"></span> 
  <span class=\"dot\" onclick=\"currentSlide(2)\"></span> 
  <span class=\"dot\" onclick=\"currentSlide(3)\"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName(\"mySlides\");
  var dots = document.getElementsByClassName(\"dot\");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = \"none\";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(\" active\", \"\");
  }
  slides[slideIndex-1].style.display = \"block\";  
  dots[slideIndex-1].className += \" active\";
}
</script>
";
        
        $__internal_0e3345ee67db3f7d3c9c5bb2148d01ace5542cf085e3d55ae9fd9581ccb845ae->leave($__internal_0e3345ee67db3f7d3c9c5bb2148d01ace5542cf085e3d55ae9fd9581ccb845ae_prof);

    }

    public function getTemplateName()
    {
        return "Vehiculos/Vehiculos.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 33,  81 => 27,  72 => 21,  63 => 16,  57 => 15,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>Aquí encontraras una breve descripción de los vehículos que encontraras en el juego</br>*/
/* <br>Camión de artillería: Es un vehículos con una torreta montada en la parte de atrás. Tiene mucha potencia de fuego, pero tiene un blindaje ligero que lo</br>*/
/* <br>vuelve bastante débil a corto alcance</br>*/
/* <br></br>*/
/* <br>Tanque de tierra: Un tanque con una potencia de fuego moderado, capaz de defenderse desde todas las direcciones pero muy lento. Es capaz de romper las</br>*/
/* <br>líneas enemigos, pero muy vulnerable a emboscadas</br>*/
/* <br></br>*/
/* <br>Tanque ligero: Un tanque con mucha movilidad pero una potencia de fuego bajo. Sirve para flanquear a los enemigos y pillarlos desprevenidos</br>*/
/* <br></br>*/
/* {% endblock %}*/
/* */
/* {% block sidebarVehiculos %}*/
/* <link rel="stylesheet" type="text/css" href="{{asset('build/css/mystile2.css')}}"/>*/
/* <div class="slideshow-container">*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">1 / 3</div>*/
/*   <img src="{{asset('build/images/Artilleria_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Camión de Artillería</div>*/
/* </div>*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">2 / 3</div>*/
/*   <img src="{{asset('build/images/Tierra_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Tanque de tierra</div>*/
/* </div>*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">3 / 3</div>*/
/*   <img src="{{asset('build/images/Ligero_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Tanque Ligero</div>*/
/* </div>*/
/* */
/* <a class="prev" onclick="plusSlides(-1)">&#10094;</a>*/
/* <a class="next" onclick="plusSlides(1)">&#10095;</a>*/
/* */
/* </div>*/
/* <br>*/
/* */
/* <div style="text-align:center">*/
/*   <span class="dot" onclick="currentSlide(1)"></span> */
/*   <span class="dot" onclick="currentSlide(2)"></span> */
/*   <span class="dot" onclick="currentSlide(3)"></span> */
/* </div>*/
/* */
/* <script>*/
/* var slideIndex = 1;*/
/* showSlides(slideIndex);*/
/* */
/* function plusSlides(n) {*/
/*   showSlides(slideIndex += n);*/
/* }*/
/* */
/* function currentSlide(n) {*/
/*   showSlides(slideIndex = n);*/
/* }*/
/* */
/* function showSlides(n) {*/
/*   var i;*/
/*   var slides = document.getElementsByClassName("mySlides");*/
/*   var dots = document.getElementsByClassName("dot");*/
/*   if (n > slides.length) {slideIndex = 1}    */
/*   if (n < 1) {slideIndex = slides.length}*/
/*   for (i = 0; i < slides.length; i++) {*/
/*       slides[i].style.display = "none";  */
/*   }*/
/*   for (i = 0; i < dots.length; i++) {*/
/*       dots[i].className = dots[i].className.replace(" active", "");*/
/*   }*/
/*   slides[slideIndex-1].style.display = "block";  */
/*   dots[slideIndex-1].className += " active";*/
/* }*/
/* </script>*/
/* {% endblock %}*/

<?php

/* armasclases/index.html.twig */
class __TwigTemplate_25a63224c53b722a7f1b8b5eb6802da2c77255c09581e50d8a9d1597dbc2e3b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasclases/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b489f8383cd136f803a48e644775728c40cd721fe73e97386d6d10c6cdfcd3f = $this->env->getExtension("native_profiler");
        $__internal_5b489f8383cd136f803a48e644775728c40cd721fe73e97386d6d10c6cdfcd3f->enter($__internal_5b489f8383cd136f803a48e644775728c40cd721fe73e97386d6d10c6cdfcd3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasclases/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5b489f8383cd136f803a48e644775728c40cd721fe73e97386d6d10c6cdfcd3f->leave($__internal_5b489f8383cd136f803a48e644775728c40cd721fe73e97386d6d10c6cdfcd3f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_663ee8edf802c44f243814c4258b0137a33e44e9f73ebcecce3deed87517a5f0 = $this->env->getExtension("native_profiler");
        $__internal_663ee8edf802c44f243814c4258b0137a33e44e9f73ebcecce3deed87517a5f0->enter($__internal_663ee8edf802c44f243814c4258b0137a33e44e9f73ebcecce3deed87517a5f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Lista de todas las armas</h1>

    <table border=\"solid black 2px\">
        <thead>
            <tr>
                <th>Arma</th>
                <th>Dmg</th>
                <th>Cargador</th>
                <th>Clase</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["armasClases"]) ? $context["armasClases"] : $this->getContext($context, "armasClases")));
        foreach ($context['_seq'] as $context["_key"] => $context["armasClase"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasClase"], "arma", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasClase"], "dmg", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasClase"], "cargador", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasClase"], "clase", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasclases_show", array("id" => $this->getAttribute($context["armasClase"], "id", array()))), "html", null, true);
            echo "\">Mostrar</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasclases_edit", array("id" => $this->getAttribute($context["armasClase"], "id", array()))), "html", null, true);
            echo "\">Editar</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['armasClase'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("armasclases_new");
        echo "\">Meter una nueva arma</a>
        </li>
    </ul>
";
        
        $__internal_663ee8edf802c44f243814c4258b0137a33e44e9f73ebcecce3deed87517a5f0->leave($__internal_663ee8edf802c44f243814c4258b0137a33e44e9f73ebcecce3deed87517a5f0_prof);

    }

    public function getTemplateName()
    {
        return "armasclases/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  99 => 35,  87 => 29,  81 => 26,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  59 => 18,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Lista de todas las armas</h1>*/
/* */
/*     <table border="solid black 2px">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <th>Dmg</th>*/
/*                 <th>Cargador</th>*/
/*                 <th>Clase</th>*/
/*                 <th>Acciones</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for armasClase in armasClases %}*/
/*             <tr>*/
/*                 <td>{{ armasClase.arma }}</td>*/
/*                 <td>{{ armasClase.dmg }}</td>*/
/*                 <td>{{ armasClase.cargador }}</td>*/
/*                 <td>{{ armasClase.clase }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('armasclases_show', { 'id': armasClase.id }) }}">Mostrar</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('armasclases_edit', { 'id': armasClase.id }) }}">Editar</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasclases_new') }}">Meter una nueva arma</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* cabecera.html.twig */
class __TwigTemplate_a1150bba3427564258fa44826f866c40846da09e1916fb7848b74ce9a661bb74 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'sidebarVehiculos' => array($this, 'block_sidebarVehiculos'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae636de328d957c54d6a7676edabc5ad2e39d11b548f4d4ed3837e55a1a8d671 = $this->env->getExtension("native_profiler");
        $__internal_ae636de328d957c54d6a7676edabc5ad2e39d11b548f4d4ed3837e55a1a8d671->enter($__internal_ae636de328d957c54d6a7676edabc5ad2e39d11b548f4d4ed3837e55a1a8d671_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cabecera.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
   
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "<img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Cabezera_Edit.jpg"), "html", null, true);
        echo "\"/>
    </head>
    <body style=\"background-image:url('";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Fondo_de_la_pagina.jpg"), "html", null, true);
        echo "')\" onload=\"mueveReloj()\">
        

<div class=\"container\">
    <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("inicio");
        echo "\">Inicio</a>
    <div class=\"dropdown\">
     <button class=\"dropbtn\" name=\"Clase\">Clases</button>
      <div class=\"dropdown-content\">
       <a href=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("asalto");
        echo "\">Asalto</a>
       <a href=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("medico");
        echo "\">Médico</a>
       <a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("apoyo");
        echo "\">Apoyo</a>
       <a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("explorador");
        echo "\">Explorador</a>
      </div>
    </div>
    \t<a href=\"";
        // line 26
        echo $this->env->getExtension('routing')->getPath("vehiculos");
        echo "\">Vehiculos</a>
        <a href=\"/armasclases\">Armas</a>
    <div class=\"dropdown\">
     <button class=\"dropbtn\" name=\"Clase\">Armas por clase</button>
      <div class=\"dropdown-content\">
       <a href=\"/armasmedico\">Armas Médico</a>
       <a href=\"/armasapoyo\">Armas Apoyo</a>
       <a href=\"/armasasalto\">Armas Asalto</a>
       <a href=\"/armasexplorador\">Armas Explorador</a>
      </div>
    </div>
</div>
        ";
        // line 38
        $this->displayBlock('body', $context, $blocks);
        // line 41
        echo "        
        ";
        // line 42
        $this->displayBlock('sidebarVehiculos', $context, $blocks);
        // line 44
        echo "        
        
        ";
        // line 46
        $this->displayBlock('javascripts', $context, $blocks);
        // line 67
        echo "        
        
      
    </body>
</html>
";
        
        $__internal_ae636de328d957c54d6a7676edabc5ad2e39d11b548f4d4ed3837e55a1a8d671->leave($__internal_ae636de328d957c54d6a7676edabc5ad2e39d11b548f4d4ed3837e55a1a8d671_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7d5bf759421f50bd47a887a9cf52b2b84cb197a9ec382fcf668e163eb8880bc9 = $this->env->getExtension("native_profiler");
        $__internal_7d5bf759421f50bd47a887a9cf52b2b84cb197a9ec382fcf668e163eb8880bc9->enter($__internal_7d5bf759421f50bd47a887a9cf52b2b84cb197a9ec382fcf668e163eb8880bc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Battlefield_1";
        
        $__internal_7d5bf759421f50bd47a887a9cf52b2b84cb197a9ec382fcf668e163eb8880bc9->leave($__internal_7d5bf759421f50bd47a887a9cf52b2b84cb197a9ec382fcf668e163eb8880bc9_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_73a7df2ec98db9a1b49c266c0a47caa04184ff80b17d28cc8057fc3c434b7b90 = $this->env->getExtension("native_profiler");
        $__internal_73a7df2ec98db9a1b49c266c0a47caa04184ff80b17d28cc8057fc3c434b7b90->enter($__internal_73a7df2ec98db9a1b49c266c0a47caa04184ff80b17d28cc8057fc3c434b7b90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/css/mystile.css"), "html", null, true);
        echo "\"/>
        ";
        
        $__internal_73a7df2ec98db9a1b49c266c0a47caa04184ff80b17d28cc8057fc3c434b7b90->leave($__internal_73a7df2ec98db9a1b49c266c0a47caa04184ff80b17d28cc8057fc3c434b7b90_prof);

    }

    // line 38
    public function block_body($context, array $blocks = array())
    {
        $__internal_50b31a701b44745453ac52973ba38541f08f77d5023612974f12f2533a6335ff = $this->env->getExtension("native_profiler");
        $__internal_50b31a701b44745453ac52973ba38541f08f77d5023612974f12f2533a6335ff->enter($__internal_50b31a701b44745453ac52973ba38541f08f77d5023612974f12f2533a6335ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 39
        echo "        
        ";
        
        $__internal_50b31a701b44745453ac52973ba38541f08f77d5023612974f12f2533a6335ff->leave($__internal_50b31a701b44745453ac52973ba38541f08f77d5023612974f12f2533a6335ff_prof);

    }

    // line 42
    public function block_sidebarVehiculos($context, array $blocks = array())
    {
        $__internal_937af6c54b8c46265d261378172e0ee99bd2b87bf7d38bac7097bb46acb6985c = $this->env->getExtension("native_profiler");
        $__internal_937af6c54b8c46265d261378172e0ee99bd2b87bf7d38bac7097bb46acb6985c->enter($__internal_937af6c54b8c46265d261378172e0ee99bd2b87bf7d38bac7097bb46acb6985c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebarVehiculos"));

        // line 43
        echo "            
        ";
        
        $__internal_937af6c54b8c46265d261378172e0ee99bd2b87bf7d38bac7097bb46acb6985c->leave($__internal_937af6c54b8c46265d261378172e0ee99bd2b87bf7d38bac7097bb46acb6985c_prof);

    }

    // line 46
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_62e8edc37d21bd65545e58afc1423983640c5934cd482e2b4c0fcd67379fe1fd = $this->env->getExtension("native_profiler");
        $__internal_62e8edc37d21bd65545e58afc1423983640c5934cd482e2b4c0fcd67379fe1fd->enter($__internal_62e8edc37d21bd65545e58afc1423983640c5934cd482e2b4c0fcd67379fe1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 47
        echo "<script language=\"JavaScript\"> 
function mueveReloj()
{ 
   \tmomentoActual = new Date(); 
   \thora = momentoActual.getHours(); 
   \tminuto = momentoActual.getMinutes(); 
   \tsegundo = momentoActual.getSeconds(); 

   \thoraImprimible = hora + \" : \" + minuto + \" : \" + segundo;

   \tdocument.form_reloj.reloj.value = horaImprimible; 

   \tsetTimeout(\"mueveReloj()\",1000); 
} 
</script> 

<form name=\"form_reloj\"> 
<input type=\"text\" name=\"reloj\" size=\"10\"> 
</form> 
        ";
        
        $__internal_62e8edc37d21bd65545e58afc1423983640c5934cd482e2b4c0fcd67379fe1fd->leave($__internal_62e8edc37d21bd65545e58afc1423983640c5934cd482e2b4c0fcd67379fe1fd_prof);

    }

    public function getTemplateName()
    {
        return "cabecera.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 47,  174 => 46,  166 => 43,  160 => 42,  152 => 39,  146 => 38,  136 => 8,  130 => 7,  118 => 5,  106 => 67,  104 => 46,  100 => 44,  98 => 42,  95 => 41,  93 => 38,  78 => 26,  72 => 23,  68 => 22,  64 => 21,  60 => 20,  53 => 16,  46 => 12,  40 => 10,  38 => 7,  33 => 5,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Battlefield_1{% endblock %}</title>*/
/*    */
/*         {% block stylesheets %}*/
/* <link rel="stylesheet" type="text/css" href="{{asset('build/css/mystile.css')}}"/>*/
/*         {% endblock %}*/
/* <img src="{{asset('build/images/Cabezera_Edit.jpg')}}"/>*/
/*     </head>*/
/*     <body style="background-image:url('{{asset('build/images/Fondo_de_la_pagina.jpg')}}')" onload="mueveReloj()">*/
/*         */
/* */
/* <div class="container">*/
/*     <a href="{{path('inicio')}}">Inicio</a>*/
/*     <div class="dropdown">*/
/*      <button class="dropbtn" name="Clase">Clases</button>*/
/*       <div class="dropdown-content">*/
/*        <a href="{{path('asalto')}}">Asalto</a>*/
/*        <a href="{{path('medico')}}">Médico</a>*/
/*        <a href="{{path('apoyo')}}">Apoyo</a>*/
/*        <a href="{{path('explorador')}}">Explorador</a>*/
/*       </div>*/
/*     </div>*/
/*     	<a href="{{path('vehiculos')}}">Vehiculos</a>*/
/*         <a href="/armasclases">Armas</a>*/
/*     <div class="dropdown">*/
/*      <button class="dropbtn" name="Clase">Armas por clase</button>*/
/*       <div class="dropdown-content">*/
/*        <a href="/armasmedico">Armas Médico</a>*/
/*        <a href="/armasapoyo">Armas Apoyo</a>*/
/*        <a href="/armasasalto">Armas Asalto</a>*/
/*        <a href="/armasexplorador">Armas Explorador</a>*/
/*       </div>*/
/*     </div>*/
/* </div>*/
/*         {% block body %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block sidebarVehiculos %}*/
/*             */
/*         {% endblock %}        */
/*         */
/*         {% block javascripts %}*/
/* <script language="JavaScript"> */
/* function mueveReloj()*/
/* { */
/*    	momentoActual = new Date(); */
/*    	hora = momentoActual.getHours(); */
/*    	minuto = momentoActual.getMinutes(); */
/*    	segundo = momentoActual.getSeconds(); */
/* */
/*    	horaImprimible = hora + " : " + minuto + " : " + segundo;*/
/* */
/*    	document.form_reloj.reloj.value = horaImprimible; */
/* */
/*    	setTimeout("mueveReloj()",1000); */
/* } */
/* </script> */
/* */
/* <form name="form_reloj"> */
/* <input type="text" name="reloj" size="10"> */
/* </form> */
/*         {% endblock %}*/
/*         */
/*         */
/*       */
/*     </body>*/
/* </html>*/
/* */

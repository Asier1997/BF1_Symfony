<?php

/* armasclases/new.html.twig */
class __TwigTemplate_0c3c438a23a1d670850098b1b5952c4d43c15637347cf1850479f8f941c2a7dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasclases/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c6ec19e99245cc6e9627bbeeb9be33ad9686cff7c3c1016b5db44ef7432466f = $this->env->getExtension("native_profiler");
        $__internal_9c6ec19e99245cc6e9627bbeeb9be33ad9686cff7c3c1016b5db44ef7432466f->enter($__internal_9c6ec19e99245cc6e9627bbeeb9be33ad9686cff7c3c1016b5db44ef7432466f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasclases/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c6ec19e99245cc6e9627bbeeb9be33ad9686cff7c3c1016b5db44ef7432466f->leave($__internal_9c6ec19e99245cc6e9627bbeeb9be33ad9686cff7c3c1016b5db44ef7432466f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_575d2136cf3ff2950186c05486301d3918f8e221014e5fc1362d7d0bff6d5452 = $this->env->getExtension("native_profiler");
        $__internal_575d2136cf3ff2950186c05486301d3918f8e221014e5fc1362d7d0bff6d5452->enter($__internal_575d2136cf3ff2950186c05486301d3918f8e221014e5fc1362d7d0bff6d5452_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Añadir Arma nueva</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Añadir\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasclases_index");
        echo "\">Volver a la lista de armas</a>
        </li>
    </ul>
";
        
        $__internal_575d2136cf3ff2950186c05486301d3918f8e221014e5fc1362d7d0bff6d5452->leave($__internal_575d2136cf3ff2950186c05486301d3918f8e221014e5fc1362d7d0bff6d5452_prof);

    }

    public function getTemplateName()
    {
        return "armasclases/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Añadir Arma nueva</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Añadir" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasclases_index') }}">Volver a la lista de armas</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* Medico/Medico.html.twig */
class __TwigTemplate_a7ebfa2925e76197bdcbe26c71e6dfd0ddb2eeb3ad26509f6971b2245c239d11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Medico/Medico.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4eb61a6480c794debe346f4f4df0733e169df61d9f71d0b3e2813dc5808a5e1 = $this->env->getExtension("native_profiler");
        $__internal_c4eb61a6480c794debe346f4f4df0733e169df61d9f71d0b3e2813dc5808a5e1->enter($__internal_c4eb61a6480c794debe346f4f4df0733e169df61d9f71d0b3e2813dc5808a5e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Medico/Medico.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4eb61a6480c794debe346f4f4df0733e169df61d9f71d0b3e2813dc5808a5e1->leave($__internal_c4eb61a6480c794debe346f4f4df0733e169df61d9f71d0b3e2813dc5808a5e1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ea2d14cc4dac5e752af85827d423fa9a9e639654765a00a399832d21a0e750b0 = $this->env->getExtension("native_profiler");
        $__internal_ea2d14cc4dac5e752af85827d423fa9a9e639654765a00a399832d21a0e750b0->enter($__internal_ea2d14cc4dac5e752af85827d423fa9a9e639654765a00a399832d21a0e750b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<br>En esta página encontraras la guía de la clase del médico</br>
<br>El medico dispone de armas de medio-largo alcance, fusiles semiautomáticos capaces de eliminar a enemigos a distancias considerables. La función principal del médico es la de</br>
<br>curar y revivir a los compañeros caídos, mediante el uso de jeringuillas y botiquines. Aunque puede cambiar sus dispositivos para ser más agresivo. Por ejemplo cambiarse la jeringuilla</br>
<br>por un lanzagranadas.</br>
<br></br>
<br>Si quieres jugar como un verdadero médico,  deberías llevar siempre la jeringuilla(para curar a los compañeros caídos) y el botiquín(para restaurar salud más rápido). Tu estrategia debería</br>
<br>consistir en intentar mantenerte a una distancia segura y curar o revivir a tus aliados, pero tampoco estas indefenso. Tu rifle semiautomático es una muy buena arma a medias-largas</br>
<br>y casi ninguna clase podrá hacerte frente.</br>
<br></br>
<br>Si quieres jugar de forma más agresiva, deberías ir con el lanzagranadas(para que los enemigos tenga que salir de las coberturas) y el botiquín. Con estos dispositivos deberías ser capaz</br>
<br>de hacer frente a cualquier clase a medias distancias, así que ten cuidado a cortas distancias. Los asaltos serán muy peligrosos a cortas distancias, así que anda con cuidado.</br>

<img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Medico_edit.jpg"), "html", null, true);
        echo "\"/>
";
        
        $__internal_ea2d14cc4dac5e752af85827d423fa9a9e639654765a00a399832d21a0e750b0->leave($__internal_ea2d14cc4dac5e752af85827d423fa9a9e639654765a00a399832d21a0e750b0_prof);

    }

    public function getTemplateName()
    {
        return "Medico/Medico.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block body %}*/
/* <br>En esta página encontraras la guía de la clase del médico</br>*/
/* <br>El medico dispone de armas de medio-largo alcance, fusiles semiautomáticos capaces de eliminar a enemigos a distancias considerables. La función principal del médico es la de</br>*/
/* <br>curar y revivir a los compañeros caídos, mediante el uso de jeringuillas y botiquines. Aunque puede cambiar sus dispositivos para ser más agresivo. Por ejemplo cambiarse la jeringuilla</br>*/
/* <br>por un lanzagranadas.</br>*/
/* <br></br>*/
/* <br>Si quieres jugar como un verdadero médico,  deberías llevar siempre la jeringuilla(para curar a los compañeros caídos) y el botiquín(para restaurar salud más rápido). Tu estrategia debería</br>*/
/* <br>consistir en intentar mantenerte a una distancia segura y curar o revivir a tus aliados, pero tampoco estas indefenso. Tu rifle semiautomático es una muy buena arma a medias-largas</br>*/
/* <br>y casi ninguna clase podrá hacerte frente.</br>*/
/* <br></br>*/
/* <br>Si quieres jugar de forma más agresiva, deberías ir con el lanzagranadas(para que los enemigos tenga que salir de las coberturas) y el botiquín. Con estos dispositivos deberías ser capaz</br>*/
/* <br>de hacer frente a cualquier clase a medias distancias, así que ten cuidado a cortas distancias. Los asaltos serán muy peligrosos a cortas distancias, así que anda con cuidado.</br>*/
/* */
/* <img src="{{asset('build/images/Medico_edit.jpg')}}"/>*/
/* {% endblock %}*/

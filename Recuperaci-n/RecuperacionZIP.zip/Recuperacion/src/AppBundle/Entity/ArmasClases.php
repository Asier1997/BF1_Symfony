<?php

namespace AppBundle\Entity;

/**
 * ArmasClases
 */
class ArmasClases
{
    /**
     * @var string
     */
    private $arma;

    /**
     * @var integer
     */
    private $dmg;

    /**
     * @var integer
     */
    private $cargador;

    /**
     * @var string
     */
    private $clase;

    /**
     * @var integer
     */
    private $id;


    /**
     * Set arma
     *
     * @param string $arma
     *
     * @return ArmasClases
     */
    public function setArma($arma)
    {
        $this->arma = $arma;

        return $this;
    }

    /**
     * Get arma
     *
     * @return string
     */
    public function getArma()
    {
        return $this->arma;
    }

    /**
     * Set dmg
     *
     * @param integer $dmg
     *
     * @return ArmasClases
     */
    public function setDmg($dmg)
    {
        $this->dmg = $dmg;

        return $this;
    }

    /**
     * Get dmg
     *
     * @return integer
     */
    public function getDmg()
    {
        return $this->dmg;
    }

    /**
     * Set cargador
     *
     * @param integer $cargador
     *
     * @return ArmasClases
     */
    public function setCargador($cargador)
    {
        $this->cargador = $cargador;

        return $this;
    }

    /**
     * Get cargador
     *
     * @return integer
     */
    public function getCargador()
    {
        return $this->cargador;
    }

    /**
     * Set clase
     *
     * @param string $clase
     *
     * @return ArmasClases
     */
    public function setClase($clase)
    {
        $this->clase = $clase;

        return $this;
    }

    /**
     * Get clase
     *
     * @return string
     */
    public function getClase()
    {
        return $this->clase;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}

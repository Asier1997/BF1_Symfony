<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Inicio/Inicio.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
     /**
     * @Route("/inicio", name="inicio")
     */
    public function inicioAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Inicio/Inicio.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
     /**
     * @Route("/asalto", name="asalto")
     */
    public function asaltoAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Asalto/Asalto.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
     /**
     * @Route("/apoyo", name="apoyo")
     */
    public function apoyoAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Apoyo/Apoyo.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
     
     /**
     * @Route("/medico", name="medico")
     */
    public function medicoAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Medico/Medico.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
    /**
     * @Route("/explorador", name="explorador")
     */
    public function exploradorAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Explorador/Explorador.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
    /**
     * @Route("/vehiculos", name="vehiculos")
     */
    public function vehiculosAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('Vehiculos/Vehiculos.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ));
    }
    
    /**
     * Lista de las armas del Asalto.
     *
     * @Route("/armasasalto", name="armasarasasalto")
     * @Method("GET")
     */
    public function armasasaltoAction()
    {
        $em = $this->getDoctrine()->getManager();
        
        $filtro ["clase"] = 'Asalto';

        $armasClases = $em->getRepository('AppBundle:ArmasClases')->findBy($filtro);

        return $this->render('armasclases/index.html.twig', array(
            'armasClases' => $armasClases,
        ));
    }
    
        /**
     * Lista de las armas del Medico.
     *
     * @Route("/armasmedico", name="armasarmedico")
     * @Method("GET")
     */
    public function armasamedicoAction()
    {
        $em = $this->getDoctrine()->getManager();
        
        $filtro ["clase"] = 'Medico';

        $armasClases = $em->getRepository('AppBundle:ArmasClases')->findBy($filtro);

        return $this->render('armasclases/index.html.twig', array(
            'armasClases' => $armasClases,
        ));
    }
    
            /**
     * Lista de las armas del Apoyo.
     *
     * @Route("/armasapoyo", name="armasarapoyo")
     * @Method("GET")
     */
    public function armasapoyoAction()
    {
        $em = $this->getDoctrine()->getManager();
        
        $filtro ["clase"] = 'Apoyo';

        $armasClases = $em->getRepository('AppBundle:ArmasClases')->findBy($filtro);

        return $this->render('armasclases/index.html.twig', array(
            'armasClases' => $armasClases,
        ));
    }
   
     /**
     * Lista de las armas del explorador.
     *
     * @Route("/armasexplorador", name="armasaexplorador")
     * @Method("GET")
     */
    
    public function armasaexploradorAction()
    {
        $em = $this->getDoctrine()->getManager();
        
        $filtro ["clase"] = 'Explorador';

        $armasClases = $em->getRepository('AppBundle:ArmasClases')->findBy($filtro);

        return $this->render('armasclases/index.html.twig', array(
            'armasClases' => $armasClases,
        ));
    }
    
  }


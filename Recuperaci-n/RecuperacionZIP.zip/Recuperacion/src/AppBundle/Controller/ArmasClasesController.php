<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\ArmasClases;
use AppBundle\Form\ArmasClasesType;

/**
 * ArmasClases controller.
 *
 * @Route("/armasclases")
 */
class ArmasClasesController extends Controller
{
    /**
     * Lists all ArmasClases entities.
     *
     * @Route("/", name="armasclases_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $armasClases = $em->getRepository('AppBundle:ArmasClases')->findAll();

        return $this->render('armasclases/index.html.twig', array(
            'armasClases' => $armasClases,
        ));
    }

    /**
     * Creates a new ArmasClases entity.
     *
     * @Route("/new", name="armasclases_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $armasClase = new ArmasClases();
        $form = $this->createForm('AppBundle\Form\ArmasClasesType', $armasClase);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($armasClase);
            $em->flush();

            return $this->redirectToRoute('armasclases_show', array('id' => $armasClase->getId()));
        }

        return $this->render('armasclases/new.html.twig', array(
            'armasClase' => $armasClase,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a ArmasClases entity.
     *
     * @Route("/{id}", name="armasclases_show")
     * @Method("GET")
     */
    public function showAction(ArmasClases $armasClase)
    {
        $deleteForm = $this->createDeleteForm($armasClase);

        return $this->render('armasclases/show.html.twig', array(
            'armasClase' => $armasClase,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing ArmasClases entity.
     *
     * @Route("/{id}/edit", name="armasclases_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, ArmasClases $armasClase)
    {
        $deleteForm = $this->createDeleteForm($armasClase);
        $editForm = $this->createForm('AppBundle\Form\ArmasClasesType', $armasClase);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($armasClase);
            $em->flush();

            return $this->redirectToRoute('armasclases_edit', array('id' => $armasClase->getId()));
        }

        return $this->render('armasclases/edit.html.twig', array(
            'armasClase' => $armasClase,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a ArmasClases entity.
     *
     * @Route("/{id}", name="armasclases_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, ArmasClases $armasClase)
    {
        $form = $this->createDeleteForm($armasClase);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($armasClase);
            $em->flush();
        }

        return $this->redirectToRoute('armasclases_index');
    }

    /**
     * Creates a form to delete a ArmasClases entity.
     *
     * @param ArmasClases $armasClase The ArmasClases entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(ArmasClases $armasClase)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('armasclases_delete', array('id' => $armasClase->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}

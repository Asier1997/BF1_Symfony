<?php

/* Asalto/Asalto.html.twig */
class __TwigTemplate_ab6d973d7a1059ac3e7d7ddfcd8d1101fe87e0cc51acd2708fc87d264e9fce9e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Asalto/Asalto.html.twig", 1);
        $this->blocks = array(
            'textoAsalto' => array($this, 'block_textoAsalto'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f52bf5ab180b8db071c138266bdeb14a21c3d92ee9b2ca2c5b00de4c3610c9d0 = $this->env->getExtension("native_profiler");
        $__internal_f52bf5ab180b8db071c138266bdeb14a21c3d92ee9b2ca2c5b00de4c3610c9d0->enter($__internal_f52bf5ab180b8db071c138266bdeb14a21c3d92ee9b2ca2c5b00de4c3610c9d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Asalto/Asalto.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f52bf5ab180b8db071c138266bdeb14a21c3d92ee9b2ca2c5b00de4c3610c9d0->leave($__internal_f52bf5ab180b8db071c138266bdeb14a21c3d92ee9b2ca2c5b00de4c3610c9d0_prof);

    }

    // line 3
    public function block_textoAsalto($context, array $blocks = array())
    {
        $__internal_e78579a8d3eb3266925e49ab86204031f1b23e6a8284cdf518fcd5241ad03cca = $this->env->getExtension("native_profiler");
        $__internal_e78579a8d3eb3266925e49ab86204031f1b23e6a8284cdf518fcd5241ad03cca->enter($__internal_e78579a8d3eb3266925e49ab86204031f1b23e6a8284cdf518fcd5241ad03cca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoAsalto"));

        // line 4
        echo "<br>Aqui encontraras la guia de la clase de Asalto.</br>

<br>El asalto tiene armas de corto-media alcance, dispone de subfusiles y de escopetas como armas principales. Su función principal es la de ocuparse de los vehículos enemigos y asaltar posiciones enemigas fortificadas</br>
<br>Para esto, utiliza como \"gadget\" unas granadas antitanque, que son muy efectivas a la hora de sacar enemigos cubiertos y destruir tanques, y un rifle antitanque de medio alcance, el cual se puede utilizar para acabar</br>
<br>con la infantería enemiga que está muy lejos o dañar vehículos enemigos.</br>

<br>La estrategia que deberías seguir como Asalto, debería ser la de intentar acercarte a los enemigos lo máximo posible para sacarle el mayor provecho a tus armas y a tus granadas antitanque. Aunque si ves enemigos en</br>
<br>campo abierto, puedes intentar darles con tu rifle antitanque. Pero cuidado, el rifle antitanque tarda bastante en recargar así que mide bien tu disparo.</br>
<br></br>
<img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Asalto_Ingles_Edit.jpg"), "html", null, true);
        echo "\"/>
 
";
        
        $__internal_e78579a8d3eb3266925e49ab86204031f1b23e6a8284cdf518fcd5241ad03cca->leave($__internal_e78579a8d3eb3266925e49ab86204031f1b23e6a8284cdf518fcd5241ad03cca_prof);

    }

    public function getTemplateName()
    {
        return "Asalto/Asalto.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 13,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoAsalto %}*/
/* <br>Aqui encontraras la guia de la clase de Asalto.</br>*/
/* */
/* <br>El asalto tiene armas de corto-media alcance, dispone de subfusiles y de escopetas como armas principales. Su función principal es la de ocuparse de los vehículos enemigos y asaltar posiciones enemigas fortificadas</br>*/
/* <br>Para esto, utiliza como "gadget" unas granadas antitanque, que son muy efectivas a la hora de sacar enemigos cubiertos y destruir tanques, y un rifle antitanque de medio alcance, el cual se puede utilizar para acabar</br>*/
/* <br>con la infantería enemiga que está muy lejos o dañar vehículos enemigos.</br>*/
/* */
/* <br>La estrategia que deberías seguir como Asalto, debería ser la de intentar acercarte a los enemigos lo máximo posible para sacarle el mayor provecho a tus armas y a tus granadas antitanque. Aunque si ves enemigos en</br>*/
/* <br>campo abierto, puedes intentar darles con tu rifle antitanque. Pero cuidado, el rifle antitanque tarda bastante en recargar así que mide bien tu disparo.</br>*/
/* <br></br>*/
/* <img src="{{asset('build/images/Asalto_Ingles_Edit.jpg')}}"/>*/
/*  */
/* {% endblock %}*/
/* */

<?php

/* armasapoyo/index.html.twig */
class __TwigTemplate_b8bc329fd0af0b47e9ab943a61c9ce6523051eef0425038d155713148fa7de62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasapoyo/index.html.twig", 1);
        $this->blocks = array(
            'datosApoyo' => array($this, 'block_datosApoyo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d9f9c51be4944730e8b74fc4930be9e7ab2c13bcd3eb89d68ac17cce55feb00 = $this->env->getExtension("native_profiler");
        $__internal_3d9f9c51be4944730e8b74fc4930be9e7ab2c13bcd3eb89d68ac17cce55feb00->enter($__internal_3d9f9c51be4944730e8b74fc4930be9e7ab2c13bcd3eb89d68ac17cce55feb00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasapoyo/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d9f9c51be4944730e8b74fc4930be9e7ab2c13bcd3eb89d68ac17cce55feb00->leave($__internal_3d9f9c51be4944730e8b74fc4930be9e7ab2c13bcd3eb89d68ac17cce55feb00_prof);

    }

    // line 3
    public function block_datosApoyo($context, array $blocks = array())
    {
        $__internal_dca133a398973087e105ec732c2d99532822584f7320ada83ee6b2deb6d8c52d = $this->env->getExtension("native_profiler");
        $__internal_dca133a398973087e105ec732c2d99532822584f7320ada83ee6b2deb6d8c52d->enter($__internal_dca133a398973087e105ec732c2d99532822584f7320ada83ee6b2deb6d8c52d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosApoyo"));

        // line 4
        echo "    <h1>Armas del Apoyo</h1>

    <table border=\"solid black 2px\">
        <thead>
            <tr>
                <th>Arma</th>
                <th>Dmg</th>
                <th>Cargador</th>
                <th>Id</th>
                <th>Accciones</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["armasApoyos"]) ? $context["armasApoyos"] : $this->getContext($context, "armasApoyos")));
        foreach ($context['_seq'] as $context["_key"] => $context["armasApoyo"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasApoyo"], "arma", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasApoyo"], "dmg", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasApoyo"], "cargador", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasApoyo"], "id", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasapoyo_show", array("id" => $this->getAttribute($context["armasApoyo"], "id", array()))), "html", null, true);
            echo "\">Mostrar</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasapoyo_edit", array("id" => $this->getAttribute($context["armasApoyo"], "id", array()))), "html", null, true);
            echo "\">Editar</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['armasApoyo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("armasapoyo_new");
        echo "\">Meter nueva arma</a>
        </li>
    </ul>
";
        
        $__internal_dca133a398973087e105ec732c2d99532822584f7320ada83ee6b2deb6d8c52d->leave($__internal_dca133a398973087e105ec732c2d99532822584f7320ada83ee6b2deb6d8c52d_prof);

    }

    public function getTemplateName()
    {
        return "armasapoyo/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  99 => 35,  87 => 29,  81 => 26,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  59 => 18,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosApoyo %}*/
/*     <h1>Armas del Apoyo</h1>*/
/* */
/*     <table border="solid black 2px">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <th>Dmg</th>*/
/*                 <th>Cargador</th>*/
/*                 <th>Id</th>*/
/*                 <th>Accciones</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for armasApoyo in armasApoyos %}*/
/*             <tr>*/
/*                 <td>{{ armasApoyo.arma }}</td>*/
/*                 <td>{{ armasApoyo.dmg }}</td>*/
/*                 <td>{{ armasApoyo.cargador }}</td>*/
/*                 <td>{{ armasApoyo.id }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('armasapoyo_show', { 'id': armasApoyo.id }) }}">Mostrar</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('armasapoyo_edit', { 'id': armasApoyo.id }) }}">Editar</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasapoyo_new') }}">Meter nueva arma</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

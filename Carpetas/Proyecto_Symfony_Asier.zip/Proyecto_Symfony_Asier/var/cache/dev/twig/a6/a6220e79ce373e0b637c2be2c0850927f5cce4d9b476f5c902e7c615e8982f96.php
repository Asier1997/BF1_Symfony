<?php

/* cabecera.html.twig */
class __TwigTemplate_90a8654a101fa88da827c6e8cb3705ea4df32d8157b3aa87d5b4a4d2501de914 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
            'textoInicio' => array($this, 'block_textoInicio'),
            'textoAsalto' => array($this, 'block_textoAsalto'),
            'textoApoyo' => array($this, 'block_textoApoyo'),
            'textoMedico' => array($this, 'block_textoMedico'),
            'textoExplorador' => array($this, 'block_textoExplorador'),
            'textoVehiculos' => array($this, 'block_textoVehiculos'),
            'sidebarVehiculos' => array($this, 'block_sidebarVehiculos'),
            'armasapoyo' => array($this, 'block_armasapoyo'),
            'armasasalto' => array($this, 'block_armasasalto'),
            'armasexplorador' => array($this, 'block_armasexplorador'),
            'armasmedico' => array($this, 'block_armasmedico'),
            'datosApoyo' => array($this, 'block_datosApoyo'),
            'datosNuevoApoyo' => array($this, 'block_datosNuevoApoyo'),
            'datosShowApoyo' => array($this, 'block_datosShowApoyo'),
            'datosEditApoyo' => array($this, 'block_datosEditApoyo'),
            'datosShowAsalto' => array($this, 'block_datosShowAsalto'),
            'datosNewAsalto' => array($this, 'block_datosNewAsalto'),
            'datosEditAsalto' => array($this, 'block_datosEditAsalto'),
            'datosIndexAsalto' => array($this, 'block_datosIndexAsalto'),
            'datosEditExplorador' => array($this, 'block_datosEditExplorador'),
            'datosIndexExplorador' => array($this, 'block_datosIndexExplorador'),
            'datosNewExplorador' => array($this, 'block_datosNewExplorador'),
            'datosShowExplorador' => array($this, 'block_datosShowExplorador'),
            'datosIndexMedico' => array($this, 'block_datosIndexMedico'),
            'datosNewMedico' => array($this, 'block_datosNewMedico'),
            'datosShowMedico' => array($this, 'block_datosShowMedico'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a8a6c8e8283a8412e3fe4f445a39c02a81d9cc65efafa822907f87ebe9ddcfc = $this->env->getExtension("native_profiler");
        $__internal_9a8a6c8e8283a8412e3fe4f445a39c02a81d9cc65efafa822907f87ebe9ddcfc->enter($__internal_9a8a6c8e8283a8412e3fe4f445a39c02a81d9cc65efafa822907f87ebe9ddcfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cabecera.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
   
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "<img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Cabezera_Edit.jpg"), "html", null, true);
        echo "\"/>
    </head>
    <body style=\"background-image:url('";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Fondo_de_la_pagina.jpg"), "html", null, true);
        echo "')\" onload=\"mueveReloj()\">
        ";
        // line 13
        $this->displayBlock('body', $context, $blocks);
        // line 38
        echo "        
        ";
        // line 39
        $this->displayBlock('javascripts', $context, $blocks);
        // line 60
        echo "        

        ";
        // line 62
        $this->displayBlock('textoInicio', $context, $blocks);
        // line 65
        echo "        
        ";
        // line 66
        $this->displayBlock('textoAsalto', $context, $blocks);
        // line 69
        echo "        
        ";
        // line 70
        $this->displayBlock('textoApoyo', $context, $blocks);
        // line 73
        echo "        
        ";
        // line 74
        $this->displayBlock('textoMedico', $context, $blocks);
        // line 77
        echo "        
        ";
        // line 78
        $this->displayBlock('textoExplorador', $context, $blocks);
        // line 81
        echo "        
        ";
        // line 82
        $this->displayBlock('textoVehiculos', $context, $blocks);
        // line 85
        echo "
        ";
        // line 86
        $this->displayBlock('sidebarVehiculos', $context, $blocks);
        // line 89
        echo "        
        ";
        // line 90
        $this->displayBlock('armasapoyo', $context, $blocks);
        // line 93
        echo "        
        ";
        // line 94
        $this->displayBlock('armasasalto', $context, $blocks);
        // line 97
        echo "        
        ";
        // line 98
        $this->displayBlock('armasexplorador', $context, $blocks);
        // line 101
        echo "        
        ";
        // line 102
        $this->displayBlock('armasmedico', $context, $blocks);
        // line 105
        echo "        
        ";
        // line 106
        $this->displayBlock('datosApoyo', $context, $blocks);
        // line 109
        echo "        
        ";
        // line 110
        $this->displayBlock('datosNuevoApoyo', $context, $blocks);
        // line 113
        echo "        
        ";
        // line 114
        $this->displayBlock('datosShowApoyo', $context, $blocks);
        // line 117
        echo "        
        ";
        // line 118
        $this->displayBlock('datosEditApoyo', $context, $blocks);
        // line 121
        echo "        
        ";
        // line 122
        $this->displayBlock('datosShowAsalto', $context, $blocks);
        // line 125
        echo "        
        ";
        // line 126
        $this->displayBlock('datosNewAsalto', $context, $blocks);
        // line 129
        echo "        
        ";
        // line 130
        $this->displayBlock('datosEditAsalto', $context, $blocks);
        // line 133
        echo "        
        ";
        // line 134
        $this->displayBlock('datosIndexAsalto', $context, $blocks);
        // line 137
        echo "        
        ";
        // line 138
        $this->displayBlock('datosEditExplorador', $context, $blocks);
        // line 141
        echo "        
        ";
        // line 142
        $this->displayBlock('datosIndexExplorador', $context, $blocks);
        // line 145
        echo "        
        ";
        // line 146
        $this->displayBlock('datosNewExplorador', $context, $blocks);
        // line 149
        echo "        
        ";
        // line 150
        $this->displayBlock('datosShowExplorador', $context, $blocks);
        // line 153
        echo "        
        ";
        // line 154
        $this->displayBlock('datosIndexMedico', $context, $blocks);
        // line 157
        echo "        
\t\t";
        // line 158
        $this->displayBlock('datosNewMedico', $context, $blocks);
        // line 161
        echo "\t\t
\t\t";
        // line 162
        $this->displayBlock('datosShowMedico', $context, $blocks);
        // line 165
        echo "    </body>
</html>
";
        
        $__internal_9a8a6c8e8283a8412e3fe4f445a39c02a81d9cc65efafa822907f87ebe9ddcfc->leave($__internal_9a8a6c8e8283a8412e3fe4f445a39c02a81d9cc65efafa822907f87ebe9ddcfc_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_ea807e5304bd1645417a5a327a8dce4894e0084126474f79eec57a69e202c81e = $this->env->getExtension("native_profiler");
        $__internal_ea807e5304bd1645417a5a327a8dce4894e0084126474f79eec57a69e202c81e->enter($__internal_ea807e5304bd1645417a5a327a8dce4894e0084126474f79eec57a69e202c81e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Battlefield_1";
        
        $__internal_ea807e5304bd1645417a5a327a8dce4894e0084126474f79eec57a69e202c81e->leave($__internal_ea807e5304bd1645417a5a327a8dce4894e0084126474f79eec57a69e202c81e_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_13fb49ef5db02d617744760f0cb79683d37ad8a98df4cc5476ae00c17821c7e5 = $this->env->getExtension("native_profiler");
        $__internal_13fb49ef5db02d617744760f0cb79683d37ad8a98df4cc5476ae00c17821c7e5->enter($__internal_13fb49ef5db02d617744760f0cb79683d37ad8a98df4cc5476ae00c17821c7e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/css/mystile.css"), "html", null, true);
        echo "\"/>
        ";
        
        $__internal_13fb49ef5db02d617744760f0cb79683d37ad8a98df4cc5476ae00c17821c7e5->leave($__internal_13fb49ef5db02d617744760f0cb79683d37ad8a98df4cc5476ae00c17821c7e5_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_1986e016ecd2fc4929770257124438197fc45e1e965dd02e0239ac6096ec2cf4 = $this->env->getExtension("native_profiler");
        $__internal_1986e016ecd2fc4929770257124438197fc45e1e965dd02e0239ac6096ec2cf4->enter($__internal_1986e016ecd2fc4929770257124438197fc45e1e965dd02e0239ac6096ec2cf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "
<div class=\"container\">
    <a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("inicio");
        echo "\">Inicio</a>
    <div class=\"dropdown\">
     <button class=\"dropbtn\" name=\"Clase\">Clases</button>
      <div class=\"dropdown-content\">
       <a href=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("asalto");
        echo "\">Asalto</a>
       <a href=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("medico");
        echo "\">Médico</a>
       <a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("apoyo");
        echo "\">Apoyo</a>
       <a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("explorador");
        echo "\">Explorador</a>
      </div>
    </div>
    \t<a href=\"";
        // line 26
        echo $this->env->getExtension('routing')->getPath("vehiculos");
        echo "\">Vehiculos</a>
    <div class=\"dropdown\">
     <button class=\"dropbtn\" name=\"Clase\">Armas</button>
      <div class=\"dropdown-content\">
       <a href=\"/armasmedico\">Armas Médico</a>
       <a href=\"/armasapoyo\">Armas Apoyo</a>
       <a href=\"/armasasalto\">Armas Asalto</a>
       <a href=\"/armasexplorador\">Armas Explorador</a>
      </div>
    </div>
</div>
        ";
        
        $__internal_1986e016ecd2fc4929770257124438197fc45e1e965dd02e0239ac6096ec2cf4->leave($__internal_1986e016ecd2fc4929770257124438197fc45e1e965dd02e0239ac6096ec2cf4_prof);

    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5f99b7b9ac69732fb440288c83e2a4c88a90f3b94180fea9b55e8c1f9f378f36 = $this->env->getExtension("native_profiler");
        $__internal_5f99b7b9ac69732fb440288c83e2a4c88a90f3b94180fea9b55e8c1f9f378f36->enter($__internal_5f99b7b9ac69732fb440288c83e2a4c88a90f3b94180fea9b55e8c1f9f378f36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 40
        echo "<script language=\"JavaScript\"> 
function mueveReloj()
{ 
   \tmomentoActual = new Date(); 
   \thora = momentoActual.getHours(); 
   \tminuto = momentoActual.getMinutes(); 
   \tsegundo = momentoActual.getSeconds(); 

   \thoraImprimible = hora + \" : \" + minuto + \" : \" + segundo;

   \tdocument.form_reloj.reloj.value = horaImprimible; 

   \tsetTimeout(\"mueveReloj()\",1000); 
} 
</script> 

<form name=\"form_reloj\"> 
<input type=\"text\" name=\"reloj\" size=\"10\"> 
</form> 
        ";
        
        $__internal_5f99b7b9ac69732fb440288c83e2a4c88a90f3b94180fea9b55e8c1f9f378f36->leave($__internal_5f99b7b9ac69732fb440288c83e2a4c88a90f3b94180fea9b55e8c1f9f378f36_prof);

    }

    // line 62
    public function block_textoInicio($context, array $blocks = array())
    {
        $__internal_f0e4d8203ec254a21f5bdccfdf98227aede2776c90b0626525f96db87c5dcbd8 = $this->env->getExtension("native_profiler");
        $__internal_f0e4d8203ec254a21f5bdccfdf98227aede2776c90b0626525f96db87c5dcbd8->enter($__internal_f0e4d8203ec254a21f5bdccfdf98227aede2776c90b0626525f96db87c5dcbd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoInicio"));

        // line 63
        echo "            
        ";
        
        $__internal_f0e4d8203ec254a21f5bdccfdf98227aede2776c90b0626525f96db87c5dcbd8->leave($__internal_f0e4d8203ec254a21f5bdccfdf98227aede2776c90b0626525f96db87c5dcbd8_prof);

    }

    // line 66
    public function block_textoAsalto($context, array $blocks = array())
    {
        $__internal_9d2757539a755c54ecbbb6d033dd7b6901a3b83f106893ad5e712fd8cd06a723 = $this->env->getExtension("native_profiler");
        $__internal_9d2757539a755c54ecbbb6d033dd7b6901a3b83f106893ad5e712fd8cd06a723->enter($__internal_9d2757539a755c54ecbbb6d033dd7b6901a3b83f106893ad5e712fd8cd06a723_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoAsalto"));

        // line 67
        echo "
        ";
        
        $__internal_9d2757539a755c54ecbbb6d033dd7b6901a3b83f106893ad5e712fd8cd06a723->leave($__internal_9d2757539a755c54ecbbb6d033dd7b6901a3b83f106893ad5e712fd8cd06a723_prof);

    }

    // line 70
    public function block_textoApoyo($context, array $blocks = array())
    {
        $__internal_88f54d677666e3b9c992e19e82de638859f85e15505b97fcb3e2806ee04b0381 = $this->env->getExtension("native_profiler");
        $__internal_88f54d677666e3b9c992e19e82de638859f85e15505b97fcb3e2806ee04b0381->enter($__internal_88f54d677666e3b9c992e19e82de638859f85e15505b97fcb3e2806ee04b0381_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoApoyo"));

        // line 71
        echo "
        ";
        
        $__internal_88f54d677666e3b9c992e19e82de638859f85e15505b97fcb3e2806ee04b0381->leave($__internal_88f54d677666e3b9c992e19e82de638859f85e15505b97fcb3e2806ee04b0381_prof);

    }

    // line 74
    public function block_textoMedico($context, array $blocks = array())
    {
        $__internal_25d54020ba34cd8a262daeb45b74f550110ad5d3cf365cfe6743eca878b779be = $this->env->getExtension("native_profiler");
        $__internal_25d54020ba34cd8a262daeb45b74f550110ad5d3cf365cfe6743eca878b779be->enter($__internal_25d54020ba34cd8a262daeb45b74f550110ad5d3cf365cfe6743eca878b779be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoMedico"));

        // line 75
        echo "
        ";
        
        $__internal_25d54020ba34cd8a262daeb45b74f550110ad5d3cf365cfe6743eca878b779be->leave($__internal_25d54020ba34cd8a262daeb45b74f550110ad5d3cf365cfe6743eca878b779be_prof);

    }

    // line 78
    public function block_textoExplorador($context, array $blocks = array())
    {
        $__internal_f21ad8e486f7d133ad045ee313d2e7e9f58b5a58725b9befefad34d116115d0f = $this->env->getExtension("native_profiler");
        $__internal_f21ad8e486f7d133ad045ee313d2e7e9f58b5a58725b9befefad34d116115d0f->enter($__internal_f21ad8e486f7d133ad045ee313d2e7e9f58b5a58725b9befefad34d116115d0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoExplorador"));

        // line 79
        echo "
        ";
        
        $__internal_f21ad8e486f7d133ad045ee313d2e7e9f58b5a58725b9befefad34d116115d0f->leave($__internal_f21ad8e486f7d133ad045ee313d2e7e9f58b5a58725b9befefad34d116115d0f_prof);

    }

    // line 82
    public function block_textoVehiculos($context, array $blocks = array())
    {
        $__internal_d5128da87ac5c088d516857fec707b79e25801183b194ff51593ec446d3b8ece = $this->env->getExtension("native_profiler");
        $__internal_d5128da87ac5c088d516857fec707b79e25801183b194ff51593ec446d3b8ece->enter($__internal_d5128da87ac5c088d516857fec707b79e25801183b194ff51593ec446d3b8ece_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoVehiculos"));

        // line 83
        echo "
        ";
        
        $__internal_d5128da87ac5c088d516857fec707b79e25801183b194ff51593ec446d3b8ece->leave($__internal_d5128da87ac5c088d516857fec707b79e25801183b194ff51593ec446d3b8ece_prof);

    }

    // line 86
    public function block_sidebarVehiculos($context, array $blocks = array())
    {
        $__internal_e44af94a847da8d21f9cc2d5e7f0cc3b45b78341542297ec79d2bbee479a063a = $this->env->getExtension("native_profiler");
        $__internal_e44af94a847da8d21f9cc2d5e7f0cc3b45b78341542297ec79d2bbee479a063a->enter($__internal_e44af94a847da8d21f9cc2d5e7f0cc3b45b78341542297ec79d2bbee479a063a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebarVehiculos"));

        // line 87
        echo "
        ";
        
        $__internal_e44af94a847da8d21f9cc2d5e7f0cc3b45b78341542297ec79d2bbee479a063a->leave($__internal_e44af94a847da8d21f9cc2d5e7f0cc3b45b78341542297ec79d2bbee479a063a_prof);

    }

    // line 90
    public function block_armasapoyo($context, array $blocks = array())
    {
        $__internal_2c7138349fe813d5acbb34704c41361aac5c0809e91d7937bf2ca278f0680dff = $this->env->getExtension("native_profiler");
        $__internal_2c7138349fe813d5acbb34704c41361aac5c0809e91d7937bf2ca278f0680dff->enter($__internal_2c7138349fe813d5acbb34704c41361aac5c0809e91d7937bf2ca278f0680dff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "armasapoyo"));

        // line 91
        echo "            
        ";
        
        $__internal_2c7138349fe813d5acbb34704c41361aac5c0809e91d7937bf2ca278f0680dff->leave($__internal_2c7138349fe813d5acbb34704c41361aac5c0809e91d7937bf2ca278f0680dff_prof);

    }

    // line 94
    public function block_armasasalto($context, array $blocks = array())
    {
        $__internal_48cc7b642c8ca0ebafca4de396d41d3067822a2aad427f8c6ef64c2a68a1f372 = $this->env->getExtension("native_profiler");
        $__internal_48cc7b642c8ca0ebafca4de396d41d3067822a2aad427f8c6ef64c2a68a1f372->enter($__internal_48cc7b642c8ca0ebafca4de396d41d3067822a2aad427f8c6ef64c2a68a1f372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "armasasalto"));

        // line 95
        echo "        
        ";
        
        $__internal_48cc7b642c8ca0ebafca4de396d41d3067822a2aad427f8c6ef64c2a68a1f372->leave($__internal_48cc7b642c8ca0ebafca4de396d41d3067822a2aad427f8c6ef64c2a68a1f372_prof);

    }

    // line 98
    public function block_armasexplorador($context, array $blocks = array())
    {
        $__internal_bd0f7cdef2ce1e7da03ff7a9230b79a97860f3525fd7a0fbe29c88e6d4719ad7 = $this->env->getExtension("native_profiler");
        $__internal_bd0f7cdef2ce1e7da03ff7a9230b79a97860f3525fd7a0fbe29c88e6d4719ad7->enter($__internal_bd0f7cdef2ce1e7da03ff7a9230b79a97860f3525fd7a0fbe29c88e6d4719ad7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "armasexplorador"));

        // line 99
        echo "        
        ";
        
        $__internal_bd0f7cdef2ce1e7da03ff7a9230b79a97860f3525fd7a0fbe29c88e6d4719ad7->leave($__internal_bd0f7cdef2ce1e7da03ff7a9230b79a97860f3525fd7a0fbe29c88e6d4719ad7_prof);

    }

    // line 102
    public function block_armasmedico($context, array $blocks = array())
    {
        $__internal_48a9c7b50cf970ac0839faecfac038c54f3f32fe7d92e26bf6497d4bc957d454 = $this->env->getExtension("native_profiler");
        $__internal_48a9c7b50cf970ac0839faecfac038c54f3f32fe7d92e26bf6497d4bc957d454->enter($__internal_48a9c7b50cf970ac0839faecfac038c54f3f32fe7d92e26bf6497d4bc957d454_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "armasmedico"));

        // line 103
        echo "            
        ";
        
        $__internal_48a9c7b50cf970ac0839faecfac038c54f3f32fe7d92e26bf6497d4bc957d454->leave($__internal_48a9c7b50cf970ac0839faecfac038c54f3f32fe7d92e26bf6497d4bc957d454_prof);

    }

    // line 106
    public function block_datosApoyo($context, array $blocks = array())
    {
        $__internal_30364ef29199e47df02ad5799088d4103f1a9ef8e29123ab34a954972c3bc03c = $this->env->getExtension("native_profiler");
        $__internal_30364ef29199e47df02ad5799088d4103f1a9ef8e29123ab34a954972c3bc03c->enter($__internal_30364ef29199e47df02ad5799088d4103f1a9ef8e29123ab34a954972c3bc03c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosApoyo"));

        // line 107
        echo "        
        ";
        
        $__internal_30364ef29199e47df02ad5799088d4103f1a9ef8e29123ab34a954972c3bc03c->leave($__internal_30364ef29199e47df02ad5799088d4103f1a9ef8e29123ab34a954972c3bc03c_prof);

    }

    // line 110
    public function block_datosNuevoApoyo($context, array $blocks = array())
    {
        $__internal_2f17bcc25f08fd2357dcd6e0407e6d455a03846c033e22c25b3138e17eac1d40 = $this->env->getExtension("native_profiler");
        $__internal_2f17bcc25f08fd2357dcd6e0407e6d455a03846c033e22c25b3138e17eac1d40->enter($__internal_2f17bcc25f08fd2357dcd6e0407e6d455a03846c033e22c25b3138e17eac1d40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNuevoApoyo"));

        // line 111
        echo "        
        ";
        
        $__internal_2f17bcc25f08fd2357dcd6e0407e6d455a03846c033e22c25b3138e17eac1d40->leave($__internal_2f17bcc25f08fd2357dcd6e0407e6d455a03846c033e22c25b3138e17eac1d40_prof);

    }

    // line 114
    public function block_datosShowApoyo($context, array $blocks = array())
    {
        $__internal_38175f600ec199e33eb2ec5e0703de288e2c803c64e8e0e80fa2fd8ec38aa623 = $this->env->getExtension("native_profiler");
        $__internal_38175f600ec199e33eb2ec5e0703de288e2c803c64e8e0e80fa2fd8ec38aa623->enter($__internal_38175f600ec199e33eb2ec5e0703de288e2c803c64e8e0e80fa2fd8ec38aa623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowApoyo"));

        // line 115
        echo "        
        ";
        
        $__internal_38175f600ec199e33eb2ec5e0703de288e2c803c64e8e0e80fa2fd8ec38aa623->leave($__internal_38175f600ec199e33eb2ec5e0703de288e2c803c64e8e0e80fa2fd8ec38aa623_prof);

    }

    // line 118
    public function block_datosEditApoyo($context, array $blocks = array())
    {
        $__internal_bc32f068bb3318768b418cce87597756847f37d55fe8366c1c2c146d0d7262ff = $this->env->getExtension("native_profiler");
        $__internal_bc32f068bb3318768b418cce87597756847f37d55fe8366c1c2c146d0d7262ff->enter($__internal_bc32f068bb3318768b418cce87597756847f37d55fe8366c1c2c146d0d7262ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditApoyo"));

        // line 119
        echo "        
        ";
        
        $__internal_bc32f068bb3318768b418cce87597756847f37d55fe8366c1c2c146d0d7262ff->leave($__internal_bc32f068bb3318768b418cce87597756847f37d55fe8366c1c2c146d0d7262ff_prof);

    }

    // line 122
    public function block_datosShowAsalto($context, array $blocks = array())
    {
        $__internal_bbce543a5004aad256d5ee0fe9bf7a905076c726fa234b6d7403a153ebb3d8d8 = $this->env->getExtension("native_profiler");
        $__internal_bbce543a5004aad256d5ee0fe9bf7a905076c726fa234b6d7403a153ebb3d8d8->enter($__internal_bbce543a5004aad256d5ee0fe9bf7a905076c726fa234b6d7403a153ebb3d8d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowAsalto"));

        // line 123
        echo "        
        ";
        
        $__internal_bbce543a5004aad256d5ee0fe9bf7a905076c726fa234b6d7403a153ebb3d8d8->leave($__internal_bbce543a5004aad256d5ee0fe9bf7a905076c726fa234b6d7403a153ebb3d8d8_prof);

    }

    // line 126
    public function block_datosNewAsalto($context, array $blocks = array())
    {
        $__internal_ad123a8cdea88372e5b1d317336b2b6ae135ee05fe56687ac649a507d5f1da8e = $this->env->getExtension("native_profiler");
        $__internal_ad123a8cdea88372e5b1d317336b2b6ae135ee05fe56687ac649a507d5f1da8e->enter($__internal_ad123a8cdea88372e5b1d317336b2b6ae135ee05fe56687ac649a507d5f1da8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewAsalto"));

        // line 127
        echo "        
        ";
        
        $__internal_ad123a8cdea88372e5b1d317336b2b6ae135ee05fe56687ac649a507d5f1da8e->leave($__internal_ad123a8cdea88372e5b1d317336b2b6ae135ee05fe56687ac649a507d5f1da8e_prof);

    }

    // line 130
    public function block_datosEditAsalto($context, array $blocks = array())
    {
        $__internal_065ad2654a6a90d87a72feba853f423f9fbc648672b50c0fdd8d1d65988952d6 = $this->env->getExtension("native_profiler");
        $__internal_065ad2654a6a90d87a72feba853f423f9fbc648672b50c0fdd8d1d65988952d6->enter($__internal_065ad2654a6a90d87a72feba853f423f9fbc648672b50c0fdd8d1d65988952d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditAsalto"));

        // line 131
        echo "        
        ";
        
        $__internal_065ad2654a6a90d87a72feba853f423f9fbc648672b50c0fdd8d1d65988952d6->leave($__internal_065ad2654a6a90d87a72feba853f423f9fbc648672b50c0fdd8d1d65988952d6_prof);

    }

    // line 134
    public function block_datosIndexAsalto($context, array $blocks = array())
    {
        $__internal_cc1064d1b9cc9fc8c97f7ff56f8e4072d67d65bd9d253821d509f64d37e3511d = $this->env->getExtension("native_profiler");
        $__internal_cc1064d1b9cc9fc8c97f7ff56f8e4072d67d65bd9d253821d509f64d37e3511d->enter($__internal_cc1064d1b9cc9fc8c97f7ff56f8e4072d67d65bd9d253821d509f64d37e3511d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexAsalto"));

        // line 135
        echo "        
        ";
        
        $__internal_cc1064d1b9cc9fc8c97f7ff56f8e4072d67d65bd9d253821d509f64d37e3511d->leave($__internal_cc1064d1b9cc9fc8c97f7ff56f8e4072d67d65bd9d253821d509f64d37e3511d_prof);

    }

    // line 138
    public function block_datosEditExplorador($context, array $blocks = array())
    {
        $__internal_1ca44625f326a2b628e459e881f015b9f6cd505fbd0c84b25f423eb38d20603e = $this->env->getExtension("native_profiler");
        $__internal_1ca44625f326a2b628e459e881f015b9f6cd505fbd0c84b25f423eb38d20603e->enter($__internal_1ca44625f326a2b628e459e881f015b9f6cd505fbd0c84b25f423eb38d20603e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditExplorador"));

        // line 139
        echo "        
        ";
        
        $__internal_1ca44625f326a2b628e459e881f015b9f6cd505fbd0c84b25f423eb38d20603e->leave($__internal_1ca44625f326a2b628e459e881f015b9f6cd505fbd0c84b25f423eb38d20603e_prof);

    }

    // line 142
    public function block_datosIndexExplorador($context, array $blocks = array())
    {
        $__internal_f22d71690d29297636c952b50d446f055ccff415d187259dd12ce3a92b95d579 = $this->env->getExtension("native_profiler");
        $__internal_f22d71690d29297636c952b50d446f055ccff415d187259dd12ce3a92b95d579->enter($__internal_f22d71690d29297636c952b50d446f055ccff415d187259dd12ce3a92b95d579_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexExplorador"));

        // line 143
        echo "        
        ";
        
        $__internal_f22d71690d29297636c952b50d446f055ccff415d187259dd12ce3a92b95d579->leave($__internal_f22d71690d29297636c952b50d446f055ccff415d187259dd12ce3a92b95d579_prof);

    }

    // line 146
    public function block_datosNewExplorador($context, array $blocks = array())
    {
        $__internal_d52a953d32c2a5daedd46a1f368137b392032421215fed734b7ce02504cb6006 = $this->env->getExtension("native_profiler");
        $__internal_d52a953d32c2a5daedd46a1f368137b392032421215fed734b7ce02504cb6006->enter($__internal_d52a953d32c2a5daedd46a1f368137b392032421215fed734b7ce02504cb6006_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewExplorador"));

        // line 147
        echo "        
        ";
        
        $__internal_d52a953d32c2a5daedd46a1f368137b392032421215fed734b7ce02504cb6006->leave($__internal_d52a953d32c2a5daedd46a1f368137b392032421215fed734b7ce02504cb6006_prof);

    }

    // line 150
    public function block_datosShowExplorador($context, array $blocks = array())
    {
        $__internal_b239e554f5c8cfd6976706ebd7ec5d9e1b03000ac7b798e8d0cec847df15779f = $this->env->getExtension("native_profiler");
        $__internal_b239e554f5c8cfd6976706ebd7ec5d9e1b03000ac7b798e8d0cec847df15779f->enter($__internal_b239e554f5c8cfd6976706ebd7ec5d9e1b03000ac7b798e8d0cec847df15779f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowExplorador"));

        // line 151
        echo "        
        ";
        
        $__internal_b239e554f5c8cfd6976706ebd7ec5d9e1b03000ac7b798e8d0cec847df15779f->leave($__internal_b239e554f5c8cfd6976706ebd7ec5d9e1b03000ac7b798e8d0cec847df15779f_prof);

    }

    // line 154
    public function block_datosIndexMedico($context, array $blocks = array())
    {
        $__internal_c21969dcb8632b8e693fd5f9ff5e2f39380305f70cb2632195e51b1e78f3d2fa = $this->env->getExtension("native_profiler");
        $__internal_c21969dcb8632b8e693fd5f9ff5e2f39380305f70cb2632195e51b1e78f3d2fa->enter($__internal_c21969dcb8632b8e693fd5f9ff5e2f39380305f70cb2632195e51b1e78f3d2fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexMedico"));

        // line 155
        echo "        
        ";
        
        $__internal_c21969dcb8632b8e693fd5f9ff5e2f39380305f70cb2632195e51b1e78f3d2fa->leave($__internal_c21969dcb8632b8e693fd5f9ff5e2f39380305f70cb2632195e51b1e78f3d2fa_prof);

    }

    // line 158
    public function block_datosNewMedico($context, array $blocks = array())
    {
        $__internal_919654f013d40b7dcbee60ad07ed0aa5eedba512dd1c7092632f1ad7669ae300 = $this->env->getExtension("native_profiler");
        $__internal_919654f013d40b7dcbee60ad07ed0aa5eedba512dd1c7092632f1ad7669ae300->enter($__internal_919654f013d40b7dcbee60ad07ed0aa5eedba512dd1c7092632f1ad7669ae300_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewMedico"));

        // line 159
        echo "\t\t
\t\t";
        
        $__internal_919654f013d40b7dcbee60ad07ed0aa5eedba512dd1c7092632f1ad7669ae300->leave($__internal_919654f013d40b7dcbee60ad07ed0aa5eedba512dd1c7092632f1ad7669ae300_prof);

    }

    // line 162
    public function block_datosShowMedico($context, array $blocks = array())
    {
        $__internal_3d1d7c9e33ea8cf478cca76ecdd8a8502d7aa65244dd7245e2353bc327f18f7b = $this->env->getExtension("native_profiler");
        $__internal_3d1d7c9e33ea8cf478cca76ecdd8a8502d7aa65244dd7245e2353bc327f18f7b->enter($__internal_3d1d7c9e33ea8cf478cca76ecdd8a8502d7aa65244dd7245e2353bc327f18f7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowMedico"));

        // line 163
        echo "\t\t
\t\t";
        
        $__internal_3d1d7c9e33ea8cf478cca76ecdd8a8502d7aa65244dd7245e2353bc327f18f7b->leave($__internal_3d1d7c9e33ea8cf478cca76ecdd8a8502d7aa65244dd7245e2353bc327f18f7b_prof);

    }

    public function getTemplateName()
    {
        return "cabecera.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  692 => 163,  686 => 162,  678 => 159,  672 => 158,  664 => 155,  658 => 154,  650 => 151,  644 => 150,  636 => 147,  630 => 146,  622 => 143,  616 => 142,  608 => 139,  602 => 138,  594 => 135,  588 => 134,  580 => 131,  574 => 130,  566 => 127,  560 => 126,  552 => 123,  546 => 122,  538 => 119,  532 => 118,  524 => 115,  518 => 114,  510 => 111,  504 => 110,  496 => 107,  490 => 106,  482 => 103,  476 => 102,  468 => 99,  462 => 98,  454 => 95,  448 => 94,  440 => 91,  434 => 90,  426 => 87,  420 => 86,  412 => 83,  406 => 82,  398 => 79,  392 => 78,  384 => 75,  378 => 74,  370 => 71,  364 => 70,  356 => 67,  350 => 66,  342 => 63,  336 => 62,  310 => 40,  304 => 39,  285 => 26,  279 => 23,  275 => 22,  271 => 21,  267 => 20,  260 => 16,  256 => 14,  250 => 13,  240 => 8,  234 => 7,  222 => 5,  213 => 165,  211 => 162,  208 => 161,  206 => 158,  203 => 157,  201 => 154,  198 => 153,  196 => 150,  193 => 149,  191 => 146,  188 => 145,  186 => 142,  183 => 141,  181 => 138,  178 => 137,  176 => 134,  173 => 133,  171 => 130,  168 => 129,  166 => 126,  163 => 125,  161 => 122,  158 => 121,  156 => 118,  153 => 117,  151 => 114,  148 => 113,  146 => 110,  143 => 109,  141 => 106,  138 => 105,  136 => 102,  133 => 101,  131 => 98,  128 => 97,  126 => 94,  123 => 93,  121 => 90,  118 => 89,  116 => 86,  113 => 85,  111 => 82,  108 => 81,  106 => 78,  103 => 77,  101 => 74,  98 => 73,  96 => 70,  93 => 69,  91 => 66,  88 => 65,  86 => 62,  82 => 60,  80 => 39,  77 => 38,  75 => 13,  71 => 12,  65 => 10,  63 => 7,  58 => 5,  52 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Battlefield_1{% endblock %}</title>*/
/*    */
/*         {% block stylesheets %}*/
/* <link rel="stylesheet" type="text/css" href="{{asset('build/css/mystile.css')}}"/>*/
/*         {% endblock %}*/
/* <img src="{{asset('build/images/Cabezera_Edit.jpg')}}"/>*/
/*     </head>*/
/*     <body style="background-image:url('{{asset('build/images/Fondo_de_la_pagina.jpg')}}')" onload="mueveReloj()">*/
/*         {% block body %}*/
/* */
/* <div class="container">*/
/*     <a href="{{path('inicio')}}">Inicio</a>*/
/*     <div class="dropdown">*/
/*      <button class="dropbtn" name="Clase">Clases</button>*/
/*       <div class="dropdown-content">*/
/*        <a href="{{path('asalto')}}">Asalto</a>*/
/*        <a href="{{path('medico')}}">Médico</a>*/
/*        <a href="{{path('apoyo')}}">Apoyo</a>*/
/*        <a href="{{path('explorador')}}">Explorador</a>*/
/*       </div>*/
/*     </div>*/
/*     	<a href="{{path('vehiculos')}}">Vehiculos</a>*/
/*     <div class="dropdown">*/
/*      <button class="dropbtn" name="Clase">Armas</button>*/
/*       <div class="dropdown-content">*/
/*        <a href="/armasmedico">Armas Médico</a>*/
/*        <a href="/armasapoyo">Armas Apoyo</a>*/
/*        <a href="/armasasalto">Armas Asalto</a>*/
/*        <a href="/armasexplorador">Armas Explorador</a>*/
/*       </div>*/
/*     </div>*/
/* </div>*/
/*         {% endblock %}*/
/*         */
/*         {% block javascripts %}*/
/* <script language="JavaScript"> */
/* function mueveReloj()*/
/* { */
/*    	momentoActual = new Date(); */
/*    	hora = momentoActual.getHours(); */
/*    	minuto = momentoActual.getMinutes(); */
/*    	segundo = momentoActual.getSeconds(); */
/* */
/*    	horaImprimible = hora + " : " + minuto + " : " + segundo;*/
/* */
/*    	document.form_reloj.reloj.value = horaImprimible; */
/* */
/*    	setTimeout("mueveReloj()",1000); */
/* } */
/* </script> */
/* */
/* <form name="form_reloj"> */
/* <input type="text" name="reloj" size="10"> */
/* </form> */
/*         {% endblock %}*/
/*         */
/* */
/*         {% block textoInicio %}*/
/*             */
/*         {% endblock %}*/
/*         */
/*         {% block textoAsalto %}*/
/* */
/*         {% endblock %}*/
/*         */
/*         {% block textoApoyo %}*/
/* */
/*         {% endblock %}*/
/*         */
/*         {% block textoMedico %}*/
/* */
/*         {% endblock %}*/
/*         */
/*         {% block textoExplorador %}*/
/* */
/*         {% endblock %}*/
/*         */
/*         {% block textoVehiculos %}*/
/* */
/*         {% endblock %}*/
/* */
/*         {% block sidebarVehiculos %}*/
/* */
/*         {% endblock %}*/
/*         */
/*         {% block armasapoyo %}*/
/*             */
/*         {% endblock %}*/
/*         */
/*         {% block armasasalto %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block armasexplorador %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block armasmedico %}*/
/*             */
/*         {% endblock %}*/
/*         */
/*         {% block datosApoyo %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosNuevoApoyo %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosShowApoyo %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosEditApoyo %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosShowAsalto %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosNewAsalto %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosEditAsalto %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosIndexAsalto %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosEditExplorador %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosIndexExplorador %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosNewExplorador %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosShowExplorador %}*/
/*         */
/*         {% endblock %}*/
/*         */
/*         {% block datosIndexMedico %}*/
/*         */
/*         {% endblock %}*/
/*         */
/* 		{% block datosNewMedico %}*/
/* 		*/
/* 		{% endblock %}*/
/* 		*/
/* 		{% block datosShowMedico %}*/
/* 		*/
/* 		{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */

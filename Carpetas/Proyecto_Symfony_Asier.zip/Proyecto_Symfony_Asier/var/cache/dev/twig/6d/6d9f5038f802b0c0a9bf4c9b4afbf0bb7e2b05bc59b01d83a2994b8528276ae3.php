<?php

/* base.html.twig */
class __TwigTemplate_dba0b336540b8eb0d5a4850a615b32180c64e833cbd48b109c18a939df9f5a1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7808b494af9c848e048449957c5e72dceb450000fc368cfe34cc65ccc9a73487 = $this->env->getExtension("native_profiler");
        $__internal_7808b494af9c848e048449957c5e72dceb450000fc368cfe34cc65ccc9a73487->enter($__internal_7808b494af9c848e048449957c5e72dceb450000fc368cfe34cc65ccc9a73487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_7808b494af9c848e048449957c5e72dceb450000fc368cfe34cc65ccc9a73487->leave($__internal_7808b494af9c848e048449957c5e72dceb450000fc368cfe34cc65ccc9a73487_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_7b5b5f7d8b2e03a13dc04beece87419011f3e79d329b74d0e77336fd6c9fbabb = $this->env->getExtension("native_profiler");
        $__internal_7b5b5f7d8b2e03a13dc04beece87419011f3e79d329b74d0e77336fd6c9fbabb->enter($__internal_7b5b5f7d8b2e03a13dc04beece87419011f3e79d329b74d0e77336fd6c9fbabb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_7b5b5f7d8b2e03a13dc04beece87419011f3e79d329b74d0e77336fd6c9fbabb->leave($__internal_7b5b5f7d8b2e03a13dc04beece87419011f3e79d329b74d0e77336fd6c9fbabb_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4ef1526466424a3135da09ff914b1156199d09f4ec5ed818840b23235145f8c9 = $this->env->getExtension("native_profiler");
        $__internal_4ef1526466424a3135da09ff914b1156199d09f4ec5ed818840b23235145f8c9->enter($__internal_4ef1526466424a3135da09ff914b1156199d09f4ec5ed818840b23235145f8c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_4ef1526466424a3135da09ff914b1156199d09f4ec5ed818840b23235145f8c9->leave($__internal_4ef1526466424a3135da09ff914b1156199d09f4ec5ed818840b23235145f8c9_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_6da67781e1ea755533088729aa1eb43bd18671aff81380502de7c11f2085a980 = $this->env->getExtension("native_profiler");
        $__internal_6da67781e1ea755533088729aa1eb43bd18671aff81380502de7c11f2085a980->enter($__internal_6da67781e1ea755533088729aa1eb43bd18671aff81380502de7c11f2085a980_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_6da67781e1ea755533088729aa1eb43bd18671aff81380502de7c11f2085a980->leave($__internal_6da67781e1ea755533088729aa1eb43bd18671aff81380502de7c11f2085a980_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4e24c686ccbc5483e362f5cf9817d2f248572e3fb444d596aa43d2c1e8cf8fd5 = $this->env->getExtension("native_profiler");
        $__internal_4e24c686ccbc5483e362f5cf9817d2f248572e3fb444d596aa43d2c1e8cf8fd5->enter($__internal_4e24c686ccbc5483e362f5cf9817d2f248572e3fb444d596aa43d2c1e8cf8fd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4e24c686ccbc5483e362f5cf9817d2f248572e3fb444d596aa43d2c1e8cf8fd5->leave($__internal_4e24c686ccbc5483e362f5cf9817d2f248572e3fb444d596aa43d2c1e8cf8fd5_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */

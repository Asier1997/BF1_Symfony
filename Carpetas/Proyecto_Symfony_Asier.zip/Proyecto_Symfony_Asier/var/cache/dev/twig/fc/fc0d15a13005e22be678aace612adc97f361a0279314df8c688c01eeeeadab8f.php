<?php

/* Explorador/Explorador.html.twig */
class __TwigTemplate_b23e631a2f507b0bc4b078d8fc1631f67dca00f2e68781d5eb082ffe1895a1fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Explorador/Explorador.html.twig", 1);
        $this->blocks = array(
            'textoExplorador' => array($this, 'block_textoExplorador'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3671b9857c13956f6d88a724103c2ffd742e385aa55e4f31bc01b7c8e9304d19 = $this->env->getExtension("native_profiler");
        $__internal_3671b9857c13956f6d88a724103c2ffd742e385aa55e4f31bc01b7c8e9304d19->enter($__internal_3671b9857c13956f6d88a724103c2ffd742e385aa55e4f31bc01b7c8e9304d19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Explorador/Explorador.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3671b9857c13956f6d88a724103c2ffd742e385aa55e4f31bc01b7c8e9304d19->leave($__internal_3671b9857c13956f6d88a724103c2ffd742e385aa55e4f31bc01b7c8e9304d19_prof);

    }

    // line 3
    public function block_textoExplorador($context, array $blocks = array())
    {
        $__internal_d9ae3a33f9fc1835a656bfd903f73f8ecc475ec7b813a8253c5015d3b905fdce = $this->env->getExtension("native_profiler");
        $__internal_d9ae3a33f9fc1835a656bfd903f73f8ecc475ec7b813a8253c5015d3b905fdce->enter($__internal_d9ae3a33f9fc1835a656bfd903f73f8ecc475ec7b813a8253c5015d3b905fdce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoExplorador"));

        // line 4
        echo "<br>Bienvenido a la guia del explorador</br>
<br>El explorador dispone de fusiles de precisión capaces de acabar con enemigos a distancias muy largas sin ni siquiera ellos lo sepan. Sus dispositivos son unas</br>
<br>bengalas, capaces de revelar enemigos en un área, y unos binoculares, que pueden detectar enemigos a distancias muy largas.</br>
<br></br>
<br>Como explorador, deberías de estar lejos de la acción ayudando a tus compañeros acabando con objetivos clave. También no te olvides de usar los binoculares y</br>
<br>las bengalas, esto dará mucha información a tu equipo.</br>

<img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Explorador_edit.jpg"), "html", null, true);
        echo "\" width=30% />
";
        
        $__internal_d9ae3a33f9fc1835a656bfd903f73f8ecc475ec7b813a8253c5015d3b905fdce->leave($__internal_d9ae3a33f9fc1835a656bfd903f73f8ecc475ec7b813a8253c5015d3b905fdce_prof);

    }

    public function getTemplateName()
    {
        return "Explorador/Explorador.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 11,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoExplorador %}*/
/* <br>Bienvenido a la guia del explorador</br>*/
/* <br>El explorador dispone de fusiles de precisión capaces de acabar con enemigos a distancias muy largas sin ni siquiera ellos lo sepan. Sus dispositivos son unas</br>*/
/* <br>bengalas, capaces de revelar enemigos en un área, y unos binoculares, que pueden detectar enemigos a distancias muy largas.</br>*/
/* <br></br>*/
/* <br>Como explorador, deberías de estar lejos de la acción ayudando a tus compañeros acabando con objetivos clave. También no te olvides de usar los binoculares y</br>*/
/* <br>las bengalas, esto dará mucha información a tu equipo.</br>*/
/* */
/* <img src="{{asset('build/images/Explorador_edit.jpg')}}" width=30% />*/
/* {% endblock %}*/

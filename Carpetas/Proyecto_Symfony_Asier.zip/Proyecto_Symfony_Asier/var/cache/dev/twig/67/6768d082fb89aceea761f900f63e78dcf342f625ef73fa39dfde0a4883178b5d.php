<?php

/* armasapoyo/edit.html.twig */
class __TwigTemplate_c4928263cfb470c7e09421cbf8a35bea0b70576f160728b3542a7a68fd07e8c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasapoyo/edit.html.twig", 1);
        $this->blocks = array(
            'datosEditApoyo' => array($this, 'block_datosEditApoyo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_842b8e45d6e6efa3566a8f0e96f71e1b2f3384637b987b7d66ec0038c4c89e3b = $this->env->getExtension("native_profiler");
        $__internal_842b8e45d6e6efa3566a8f0e96f71e1b2f3384637b987b7d66ec0038c4c89e3b->enter($__internal_842b8e45d6e6efa3566a8f0e96f71e1b2f3384637b987b7d66ec0038c4c89e3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasapoyo/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_842b8e45d6e6efa3566a8f0e96f71e1b2f3384637b987b7d66ec0038c4c89e3b->leave($__internal_842b8e45d6e6efa3566a8f0e96f71e1b2f3384637b987b7d66ec0038c4c89e3b_prof);

    }

    // line 3
    public function block_datosEditApoyo($context, array $blocks = array())
    {
        $__internal_4ed471720acab7b3e32bae277ce42639ae4b984dbf6120df5df3b77042f20e56 = $this->env->getExtension("native_profiler");
        $__internal_4ed471720acab7b3e32bae277ce42639ae4b984dbf6120df5df3b77042f20e56->enter($__internal_4ed471720acab7b3e32bae277ce42639ae4b984dbf6120df5df3b77042f20e56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditApoyo"));

        // line 4
        echo "    <h1>Editar arma del Apoyo</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Editar\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasapoyo_index");
        echo "\">Volver a la lista de armas del Apoyo</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_4ed471720acab7b3e32bae277ce42639ae4b984dbf6120df5df3b77042f20e56->leave($__internal_4ed471720acab7b3e32bae277ce42639ae4b984dbf6120df5df3b77042f20e56_prof);

    }

    public function getTemplateName()
    {
        return "armasapoyo/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosEditApoyo %}*/
/*     <h1>Editar arma del Apoyo</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Editar" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasapoyo_index') }}">Volver a la lista de armas del Apoyo</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* Inicio/Inicio.html.twig */
class __TwigTemplate_e3434f697346a46d662335f2c4d6a3ee21fd96db5ee935ebacc206b9e79ac598 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Inicio/Inicio.html.twig", 1);
        $this->blocks = array(
            'textoInicio' => array($this, 'block_textoInicio'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9335f3471d77a7733564c85416aaeb16c2bed7d3d9d877534202e8650294759 = $this->env->getExtension("native_profiler");
        $__internal_d9335f3471d77a7733564c85416aaeb16c2bed7d3d9d877534202e8650294759->enter($__internal_d9335f3471d77a7733564c85416aaeb16c2bed7d3d9d877534202e8650294759_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Inicio/Inicio.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d9335f3471d77a7733564c85416aaeb16c2bed7d3d9d877534202e8650294759->leave($__internal_d9335f3471d77a7733564c85416aaeb16c2bed7d3d9d877534202e8650294759_prof);

    }

    // line 3
    public function block_textoInicio($context, array $blocks = array())
    {
        $__internal_946ee845e306c1e1fad0418dd191adc6b2d0810506fdcf12ba517ede4b88bc77 = $this->env->getExtension("native_profiler");
        $__internal_946ee845e306c1e1fad0418dd191adc6b2d0810506fdcf12ba517ede4b88bc77->enter($__internal_946ee845e306c1e1fad0418dd191adc6b2d0810506fdcf12ba517ede4b88bc77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoInicio"));

        // line 4
        echo "<br>Bienvenido!</br>
<br>En esta página encontraras guías básicas de cómo funcionan las clases y los vehículos en Battlefield 1, así tendrás unas nociones básicas de cómo funciona el juego.</br>
";
        
        $__internal_946ee845e306c1e1fad0418dd191adc6b2d0810506fdcf12ba517ede4b88bc77->leave($__internal_946ee845e306c1e1fad0418dd191adc6b2d0810506fdcf12ba517ede4b88bc77_prof);

    }

    public function getTemplateName()
    {
        return "Inicio/Inicio.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoInicio %}*/
/* <br>Bienvenido!</br>*/
/* <br>En esta página encontraras guías básicas de cómo funcionan las clases y los vehículos en Battlefield 1, así tendrás unas nociones básicas de cómo funciona el juego.</br>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
/* */
/* */

<?php

/* armasmedico/index.html.twig */
class __TwigTemplate_0bde01aebff6ba71fb2e8541bfece2c4d7f39f4721a665b6c07143925f1cebf0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasmedico/index.html.twig", 1);
        $this->blocks = array(
            'datosIndexMedico' => array($this, 'block_datosIndexMedico'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b96a39201ccc09c4c9052ccc12da124b3f2bc275f9c0f6c024a6b6665ca6431 = $this->env->getExtension("native_profiler");
        $__internal_0b96a39201ccc09c4c9052ccc12da124b3f2bc275f9c0f6c024a6b6665ca6431->enter($__internal_0b96a39201ccc09c4c9052ccc12da124b3f2bc275f9c0f6c024a6b6665ca6431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasmedico/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b96a39201ccc09c4c9052ccc12da124b3f2bc275f9c0f6c024a6b6665ca6431->leave($__internal_0b96a39201ccc09c4c9052ccc12da124b3f2bc275f9c0f6c024a6b6665ca6431_prof);

    }

    // line 3
    public function block_datosIndexMedico($context, array $blocks = array())
    {
        $__internal_e5b06490a9b64ecbc6bc2b2722aecc04bc37afcd6562511f1796e54a41b284bc = $this->env->getExtension("native_profiler");
        $__internal_e5b06490a9b64ecbc6bc2b2722aecc04bc37afcd6562511f1796e54a41b284bc->enter($__internal_e5b06490a9b64ecbc6bc2b2722aecc04bc37afcd6562511f1796e54a41b284bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexMedico"));

        // line 4
        echo "    <h1>Lista de armas del Médico</h1>

    <table border=\"solid black 2px\">
        <thead>
            <tr>
                <th>Arma</th>
                <th>Dmg</th>
                <th>Cargador</th>
                <th>Id</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["armasMedicos"]) ? $context["armasMedicos"] : $this->getContext($context, "armasMedicos")));
        foreach ($context['_seq'] as $context["_key"] => $context["armasMedico"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasMedico"], "arma", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasMedico"], "dmg", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasMedico"], "cargador", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasMedico"], "id", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasmedico_show", array("id" => $this->getAttribute($context["armasMedico"], "id", array()))), "html", null, true);
            echo "\">Mostrar</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasmedico_edit", array("id" => $this->getAttribute($context["armasMedico"], "id", array()))), "html", null, true);
            echo "\">Editar</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['armasMedico'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("armasmedico_new");
        echo "\">Añadir nueva arma al Médico</a>
        </li>
    </ul>
";
        
        $__internal_e5b06490a9b64ecbc6bc2b2722aecc04bc37afcd6562511f1796e54a41b284bc->leave($__internal_e5b06490a9b64ecbc6bc2b2722aecc04bc37afcd6562511f1796e54a41b284bc_prof);

    }

    public function getTemplateName()
    {
        return "armasmedico/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  99 => 35,  87 => 29,  81 => 26,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  59 => 18,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosIndexMedico %}*/
/*     <h1>Lista de armas del Médico</h1>*/
/* */
/*     <table border="solid black 2px">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <th>Dmg</th>*/
/*                 <th>Cargador</th>*/
/*                 <th>Id</th>*/
/*                 <th>Acciones</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for armasMedico in armasMedicos %}*/
/*             <tr>*/
/*                 <td>{{ armasMedico.arma }}</td>*/
/*                 <td>{{ armasMedico.dmg }}</td>*/
/*                 <td>{{ armasMedico.cargador }}</td>*/
/*                 <td>{{ armasMedico.id }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('armasmedico_show', { 'id': armasMedico.id }) }}">Mostrar</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('armasmedico_edit', { 'id': armasMedico.id }) }}">Editar</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasmedico_new') }}">Añadir nueva arma al Médico</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* armasasalto/edit.html.twig */
class __TwigTemplate_fb978bbbb6a1e06fa35acf2a4f2bb14f41bb925bff4ce2bac41670e9600f3b4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasasalto/edit.html.twig", 1);
        $this->blocks = array(
            'datosEditAsalto' => array($this, 'block_datosEditAsalto'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c9bf35f118246073a964d7568b88c4c649976cfe38ce11b74d6924437c20bcc = $this->env->getExtension("native_profiler");
        $__internal_1c9bf35f118246073a964d7568b88c4c649976cfe38ce11b74d6924437c20bcc->enter($__internal_1c9bf35f118246073a964d7568b88c4c649976cfe38ce11b74d6924437c20bcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasasalto/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1c9bf35f118246073a964d7568b88c4c649976cfe38ce11b74d6924437c20bcc->leave($__internal_1c9bf35f118246073a964d7568b88c4c649976cfe38ce11b74d6924437c20bcc_prof);

    }

    // line 3
    public function block_datosEditAsalto($context, array $blocks = array())
    {
        $__internal_27e7b808a2d380906fabb97e373d645277bd73badb5a91769bfa2d1cff3dfc6f = $this->env->getExtension("native_profiler");
        $__internal_27e7b808a2d380906fabb97e373d645277bd73badb5a91769bfa2d1cff3dfc6f->enter($__internal_27e7b808a2d380906fabb97e373d645277bd73badb5a91769bfa2d1cff3dfc6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditAsalto"));

        // line 4
        echo "    <h1>Editar arma del Asalto</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Editar\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasasalto_index");
        echo "\">Volver a la lista de las armas del Asalto</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_27e7b808a2d380906fabb97e373d645277bd73badb5a91769bfa2d1cff3dfc6f->leave($__internal_27e7b808a2d380906fabb97e373d645277bd73badb5a91769bfa2d1cff3dfc6f_prof);

    }

    public function getTemplateName()
    {
        return "armasasalto/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosEditAsalto %}*/
/*     <h1>Editar arma del Asalto</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Editar" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasasalto_index') }}">Volver a la lista de las armas del Asalto</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* armasapoyo/new.html.twig */
class __TwigTemplate_f895c0b4c658fcbae88834aedc5a66eac8324173d6b21b9f58cef16b3635010b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasapoyo/new.html.twig", 1);
        $this->blocks = array(
            'datosNuevoApoyo' => array($this, 'block_datosNuevoApoyo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_974c6c55aac28c11c10e5cc819ecc16f4363ff8724659717cef0446900be7fbd = $this->env->getExtension("native_profiler");
        $__internal_974c6c55aac28c11c10e5cc819ecc16f4363ff8724659717cef0446900be7fbd->enter($__internal_974c6c55aac28c11c10e5cc819ecc16f4363ff8724659717cef0446900be7fbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasapoyo/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_974c6c55aac28c11c10e5cc819ecc16f4363ff8724659717cef0446900be7fbd->leave($__internal_974c6c55aac28c11c10e5cc819ecc16f4363ff8724659717cef0446900be7fbd_prof);

    }

    // line 3
    public function block_datosNuevoApoyo($context, array $blocks = array())
    {
        $__internal_6fc1f8e9fd9be6f67b45ede9bc25f64568d170ee6ff2432ebbfb8dc4393a64fc = $this->env->getExtension("native_profiler");
        $__internal_6fc1f8e9fd9be6f67b45ede9bc25f64568d170ee6ff2432ebbfb8dc4393a64fc->enter($__internal_6fc1f8e9fd9be6f67b45ede9bc25f64568d170ee6ff2432ebbfb8dc4393a64fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNuevoApoyo"));

        // line 4
        echo "    <h1>Añadir arma para el Apoyo</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Añadir\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasapoyo_index");
        echo "\">Volver a la lista de armas del Apoyo</a>
        </li>
    </ul>
";
        
        $__internal_6fc1f8e9fd9be6f67b45ede9bc25f64568d170ee6ff2432ebbfb8dc4393a64fc->leave($__internal_6fc1f8e9fd9be6f67b45ede9bc25f64568d170ee6ff2432ebbfb8dc4393a64fc_prof);

    }

    public function getTemplateName()
    {
        return "armasapoyo/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosNuevoApoyo %}*/
/*     <h1>Añadir arma para el Apoyo</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Añadir" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasapoyo_index') }}">Volver a la lista de armas del Apoyo</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

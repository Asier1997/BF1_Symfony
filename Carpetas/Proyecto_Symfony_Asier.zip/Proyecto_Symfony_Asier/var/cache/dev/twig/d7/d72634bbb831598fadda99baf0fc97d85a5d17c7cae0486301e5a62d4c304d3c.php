<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_dfc61ab4cf50083a25f372eab9bd3a3ea9eda22ccc048d113c67385b2fbca3e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c1c08faa4cbc33e6948a7cf570e7d56622bca52e804cacca9cb5bf80011c55b = $this->env->getExtension("native_profiler");
        $__internal_0c1c08faa4cbc33e6948a7cf570e7d56622bca52e804cacca9cb5bf80011c55b->enter($__internal_0c1c08faa4cbc33e6948a7cf570e7d56622bca52e804cacca9cb5bf80011c55b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0c1c08faa4cbc33e6948a7cf570e7d56622bca52e804cacca9cb5bf80011c55b->leave($__internal_0c1c08faa4cbc33e6948a7cf570e7d56622bca52e804cacca9cb5bf80011c55b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_7bb6d64540f52c996a42bb530d0053d8b4d1db1fea710323d6351d296b912d7f = $this->env->getExtension("native_profiler");
        $__internal_7bb6d64540f52c996a42bb530d0053d8b4d1db1fea710323d6351d296b912d7f->enter($__internal_7bb6d64540f52c996a42bb530d0053d8b4d1db1fea710323d6351d296b912d7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7bb6d64540f52c996a42bb530d0053d8b4d1db1fea710323d6351d296b912d7f->leave($__internal_7bb6d64540f52c996a42bb530d0053d8b4d1db1fea710323d6351d296b912d7f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_99cdf2ed6729cc91936bd903f4b30bffa5848cb0db3e4dd34862a809bc0435dc = $this->env->getExtension("native_profiler");
        $__internal_99cdf2ed6729cc91936bd903f4b30bffa5848cb0db3e4dd34862a809bc0435dc->enter($__internal_99cdf2ed6729cc91936bd903f4b30bffa5848cb0db3e4dd34862a809bc0435dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_99cdf2ed6729cc91936bd903f4b30bffa5848cb0db3e4dd34862a809bc0435dc->leave($__internal_99cdf2ed6729cc91936bd903f4b30bffa5848cb0db3e4dd34862a809bc0435dc_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_0342827c024fe25df68fbc0ddb29b9380b6bc22ca22b50b24eb7e06900de1212 = $this->env->getExtension("native_profiler");
        $__internal_0342827c024fe25df68fbc0ddb29b9380b6bc22ca22b50b24eb7e06900de1212->enter($__internal_0342827c024fe25df68fbc0ddb29b9380b6bc22ca22b50b24eb7e06900de1212_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_0342827c024fe25df68fbc0ddb29b9380b6bc22ca22b50b24eb7e06900de1212->leave($__internal_0342827c024fe25df68fbc0ddb29b9380b6bc22ca22b50b24eb7e06900de1212_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */

<?php

/* armasmedico/edit.html.twig */
class __TwigTemplate_5c9b395380e01f72f38b39aa709ac3280c04c5514c2a017a5c9009761c64741a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasmedico/edit.html.twig", 1);
        $this->blocks = array(
            'datosNewMedico' => array($this, 'block_datosNewMedico'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1dbf74d5496a28f57448133f849f313e682d347af25dd1da9559f541789605c4 = $this->env->getExtension("native_profiler");
        $__internal_1dbf74d5496a28f57448133f849f313e682d347af25dd1da9559f541789605c4->enter($__internal_1dbf74d5496a28f57448133f849f313e682d347af25dd1da9559f541789605c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasmedico/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1dbf74d5496a28f57448133f849f313e682d347af25dd1da9559f541789605c4->leave($__internal_1dbf74d5496a28f57448133f849f313e682d347af25dd1da9559f541789605c4_prof);

    }

    // line 3
    public function block_datosNewMedico($context, array $blocks = array())
    {
        $__internal_dcb24c6b143cc55d71fd986dca5b3529f637b063dab83ee3602c994f745fa804 = $this->env->getExtension("native_profiler");
        $__internal_dcb24c6b143cc55d71fd986dca5b3529f637b063dab83ee3602c994f745fa804->enter($__internal_dcb24c6b143cc55d71fd986dca5b3529f637b063dab83ee3602c994f745fa804_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewMedico"));

        // line 4
        echo "    <h1>Editar arma del Médico</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Editar\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasmedico_index");
        echo "\">Volver a la lista de armas del Médico</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_dcb24c6b143cc55d71fd986dca5b3529f637b063dab83ee3602c994f745fa804->leave($__internal_dcb24c6b143cc55d71fd986dca5b3529f637b063dab83ee3602c994f745fa804_prof);

    }

    public function getTemplateName()
    {
        return "armasmedico/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosNewMedico %}*/
/*     <h1>Editar arma del Médico</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Editar" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasmedico_index') }}">Volver a la lista de armas del Médico</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

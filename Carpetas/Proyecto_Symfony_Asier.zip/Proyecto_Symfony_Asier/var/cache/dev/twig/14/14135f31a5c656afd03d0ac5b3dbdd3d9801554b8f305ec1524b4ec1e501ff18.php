<?php

/* armasasalto/index.html.twig */
class __TwigTemplate_03c419c0f00fdb423cc1697e2fdbb8311c08cf83c3a19497380de6b0618c5102 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasasalto/index.html.twig", 1);
        $this->blocks = array(
            'datosIndexAsalto' => array($this, 'block_datosIndexAsalto'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aea2c26a6a6bd16755a8d796fefd83b2384489a4d34479f6ba4a99e04d6e9019 = $this->env->getExtension("native_profiler");
        $__internal_aea2c26a6a6bd16755a8d796fefd83b2384489a4d34479f6ba4a99e04d6e9019->enter($__internal_aea2c26a6a6bd16755a8d796fefd83b2384489a4d34479f6ba4a99e04d6e9019_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasasalto/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aea2c26a6a6bd16755a8d796fefd83b2384489a4d34479f6ba4a99e04d6e9019->leave($__internal_aea2c26a6a6bd16755a8d796fefd83b2384489a4d34479f6ba4a99e04d6e9019_prof);

    }

    // line 3
    public function block_datosIndexAsalto($context, array $blocks = array())
    {
        $__internal_4ed4a9b8aadd07e27950be82b2595860edb7919cea2d4f1a2402c2e67f91ea58 = $this->env->getExtension("native_profiler");
        $__internal_4ed4a9b8aadd07e27950be82b2595860edb7919cea2d4f1a2402c2e67f91ea58->enter($__internal_4ed4a9b8aadd07e27950be82b2595860edb7919cea2d4f1a2402c2e67f91ea58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexAsalto"));

        // line 4
        echo "    <h1>Lista de las armas del Asalto</h1>

    <table border=\"solid black 2px\">
        <thead>
            <tr>
                <th>Arma</th>
                <th>Dmg</th>
                <th>Cargador</th>
                <th>Id</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["armasAsaltos"]) ? $context["armasAsaltos"] : $this->getContext($context, "armasAsaltos")));
        foreach ($context['_seq'] as $context["_key"] => $context["armasAsalto"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasAsalto"], "arma", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasAsalto"], "dmg", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasAsalto"], "cargador", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasAsalto"], "id", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasasalto_show", array("id" => $this->getAttribute($context["armasAsalto"], "id", array()))), "html", null, true);
            echo "\">Mostrar</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasasalto_edit", array("id" => $this->getAttribute($context["armasAsalto"], "id", array()))), "html", null, true);
            echo "\">Editar</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['armasAsalto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("armasasalto_new");
        echo "\">Añadir nueva arma para el Asalto</a>
        </li>
    </ul>
";
        
        $__internal_4ed4a9b8aadd07e27950be82b2595860edb7919cea2d4f1a2402c2e67f91ea58->leave($__internal_4ed4a9b8aadd07e27950be82b2595860edb7919cea2d4f1a2402c2e67f91ea58_prof);

    }

    public function getTemplateName()
    {
        return "armasasalto/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  99 => 35,  87 => 29,  81 => 26,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  59 => 18,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosIndexAsalto %}*/
/*     <h1>Lista de las armas del Asalto</h1>*/
/* */
/*     <table border="solid black 2px">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <th>Dmg</th>*/
/*                 <th>Cargador</th>*/
/*                 <th>Id</th>*/
/*                 <th>Acciones</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for armasAsalto in armasAsaltos %}*/
/*             <tr>*/
/*                 <td>{{ armasAsalto.arma }}</td>*/
/*                 <td>{{ armasAsalto.dmg }}</td>*/
/*                 <td>{{ armasAsalto.cargador }}</td>*/
/*                 <td>{{ armasAsalto.id }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('armasasalto_show', { 'id': armasAsalto.id }) }}">Mostrar</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('armasasalto_edit', { 'id': armasAsalto.id }) }}">Editar</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasasalto_new') }}">Añadir nueva arma para el Asalto</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

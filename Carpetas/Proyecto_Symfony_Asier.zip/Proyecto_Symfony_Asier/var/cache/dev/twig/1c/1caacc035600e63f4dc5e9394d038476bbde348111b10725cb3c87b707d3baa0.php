<?php

/* Vehiculos/Vehiculos.html.twig */
class __TwigTemplate_31a856946a49ad3399780139f6fa3668d5bbaffc17aeb6317099ff3f8d98a2a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Vehiculos/Vehiculos.html.twig", 1);
        $this->blocks = array(
            'textoVehiculos' => array($this, 'block_textoVehiculos'),
            'sidebarVehiculos' => array($this, 'block_sidebarVehiculos'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adee32bdf4cfea66e2b9a926db76020789c1082f10e3b06ec49a9cadd58fb786 = $this->env->getExtension("native_profiler");
        $__internal_adee32bdf4cfea66e2b9a926db76020789c1082f10e3b06ec49a9cadd58fb786->enter($__internal_adee32bdf4cfea66e2b9a926db76020789c1082f10e3b06ec49a9cadd58fb786_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Vehiculos/Vehiculos.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_adee32bdf4cfea66e2b9a926db76020789c1082f10e3b06ec49a9cadd58fb786->leave($__internal_adee32bdf4cfea66e2b9a926db76020789c1082f10e3b06ec49a9cadd58fb786_prof);

    }

    // line 3
    public function block_textoVehiculos($context, array $blocks = array())
    {
        $__internal_fd6358833f60bc24bd22582bbdc8938c206ff04674c07fc894c12db815deea3d = $this->env->getExtension("native_profiler");
        $__internal_fd6358833f60bc24bd22582bbdc8938c206ff04674c07fc894c12db815deea3d->enter($__internal_fd6358833f60bc24bd22582bbdc8938c206ff04674c07fc894c12db815deea3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoVehiculos"));

        // line 4
        echo "<br>Aquí encontraras una breve descripción de los vehículos que encontraras en el juego</br>
<br>Camión de artillería: Es un vehículos con una torreta montada en la parte de atrás. Tiene mucha potencia de fuego, pero tiene un blindaje ligero que lo</br>
<br>vuelve bastante débil a corto alcance</br>
<br></br>
<br>Tanque de tierra: Un tanque con una potencia de fuego moderado, capaz de defenderse desde todas las direcciones pero muy lento. Es capaz de romper las</br>
<br>líneas enemigos, pero muy vulnerable a emboscadas</br>
<br></br>
<br>Tanque ligero: Un tanque con mucha movilidad pero una potencia de fuego bajo. Sirve para flanquear a los enemigos y pillarlos desprevenidos</br>
<br></br>
";
        
        $__internal_fd6358833f60bc24bd22582bbdc8938c206ff04674c07fc894c12db815deea3d->leave($__internal_fd6358833f60bc24bd22582bbdc8938c206ff04674c07fc894c12db815deea3d_prof);

    }

    // line 15
    public function block_sidebarVehiculos($context, array $blocks = array())
    {
        $__internal_a5a49fb4a4391668eb7f26a50fe5f16952d7d88beb800bd30fdba6669d3f1a4d = $this->env->getExtension("native_profiler");
        $__internal_a5a49fb4a4391668eb7f26a50fe5f16952d7d88beb800bd30fdba6669d3f1a4d->enter($__internal_a5a49fb4a4391668eb7f26a50fe5f16952d7d88beb800bd30fdba6669d3f1a4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebarVehiculos"));

        // line 16
        echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/css/mystile2.css"), "html", null, true);
        echo "\"/>
<div class=\"slideshow-container\">

<div class=\"mySlides fade\">
  <div class=\"numbertext\">1 / 3</div>
  <img src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Artilleria_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Camión de Artillería</div>
</div>

<div class=\"mySlides fade\">
  <div class=\"numbertext\">2 / 3</div>
  <img src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Tierra_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Tanque de tierra</div>
</div>

<div class=\"mySlides fade\">
  <div class=\"numbertext\">3 / 3</div>
  <img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Ligero_edit.jpg"), "html", null, true);
        echo "\" style=\"width:100%\"/>
  <div class=\"text\">Tanque Ligero</div>
</div>

<a class=\"prev\" onclick=\"plusSlides(-1)\">&#10094;</a>
<a class=\"next\" onclick=\"plusSlides(1)\">&#10095;</a>

</div>
<br>

<div style=\"text-align:center\">
  <span class=\"dot\" onclick=\"currentSlide(1)\"></span> 
  <span class=\"dot\" onclick=\"currentSlide(2)\"></span> 
  <span class=\"dot\" onclick=\"currentSlide(3)\"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName(\"mySlides\");
  var dots = document.getElementsByClassName(\"dot\");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = \"none\";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(\" active\", \"\");
  }
  slides[slideIndex-1].style.display = \"block\";  
  dots[slideIndex-1].className += \" active\";
}
</script>
";
        
        $__internal_a5a49fb4a4391668eb7f26a50fe5f16952d7d88beb800bd30fdba6669d3f1a4d->leave($__internal_a5a49fb4a4391668eb7f26a50fe5f16952d7d88beb800bd30fdba6669d3f1a4d_prof);

    }

    public function getTemplateName()
    {
        return "Vehiculos/Vehiculos.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 33,  81 => 27,  72 => 21,  63 => 16,  57 => 15,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoVehiculos %}*/
/* <br>Aquí encontraras una breve descripción de los vehículos que encontraras en el juego</br>*/
/* <br>Camión de artillería: Es un vehículos con una torreta montada en la parte de atrás. Tiene mucha potencia de fuego, pero tiene un blindaje ligero que lo</br>*/
/* <br>vuelve bastante débil a corto alcance</br>*/
/* <br></br>*/
/* <br>Tanque de tierra: Un tanque con una potencia de fuego moderado, capaz de defenderse desde todas las direcciones pero muy lento. Es capaz de romper las</br>*/
/* <br>líneas enemigos, pero muy vulnerable a emboscadas</br>*/
/* <br></br>*/
/* <br>Tanque ligero: Un tanque con mucha movilidad pero una potencia de fuego bajo. Sirve para flanquear a los enemigos y pillarlos desprevenidos</br>*/
/* <br></br>*/
/* {% endblock %}*/
/* */
/* {% block sidebarVehiculos %}*/
/* <link rel="stylesheet" type="text/css" href="{{asset('build/css/mystile2.css')}}"/>*/
/* <div class="slideshow-container">*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">1 / 3</div>*/
/*   <img src="{{asset('build/images/Artilleria_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Camión de Artillería</div>*/
/* </div>*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">2 / 3</div>*/
/*   <img src="{{asset('build/images/Tierra_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Tanque de tierra</div>*/
/* </div>*/
/* */
/* <div class="mySlides fade">*/
/*   <div class="numbertext">3 / 3</div>*/
/*   <img src="{{asset('build/images/Ligero_edit.jpg')}}" style="width:100%"/>*/
/*   <div class="text">Tanque Ligero</div>*/
/* </div>*/
/* */
/* <a class="prev" onclick="plusSlides(-1)">&#10094;</a>*/
/* <a class="next" onclick="plusSlides(1)">&#10095;</a>*/
/* */
/* </div>*/
/* <br>*/
/* */
/* <div style="text-align:center">*/
/*   <span class="dot" onclick="currentSlide(1)"></span> */
/*   <span class="dot" onclick="currentSlide(2)"></span> */
/*   <span class="dot" onclick="currentSlide(3)"></span> */
/* </div>*/
/* */
/* <script>*/
/* var slideIndex = 1;*/
/* showSlides(slideIndex);*/
/* */
/* function plusSlides(n) {*/
/*   showSlides(slideIndex += n);*/
/* }*/
/* */
/* function currentSlide(n) {*/
/*   showSlides(slideIndex = n);*/
/* }*/
/* */
/* function showSlides(n) {*/
/*   var i;*/
/*   var slides = document.getElementsByClassName("mySlides");*/
/*   var dots = document.getElementsByClassName("dot");*/
/*   if (n > slides.length) {slideIndex = 1}    */
/*   if (n < 1) {slideIndex = slides.length}*/
/*   for (i = 0; i < slides.length; i++) {*/
/*       slides[i].style.display = "none";  */
/*   }*/
/*   for (i = 0; i < dots.length; i++) {*/
/*       dots[i].className = dots[i].className.replace(" active", "");*/
/*   }*/
/*   slides[slideIndex-1].style.display = "block";  */
/*   dots[slideIndex-1].className += " active";*/
/* }*/
/* </script>*/
/* {% endblock %}*/

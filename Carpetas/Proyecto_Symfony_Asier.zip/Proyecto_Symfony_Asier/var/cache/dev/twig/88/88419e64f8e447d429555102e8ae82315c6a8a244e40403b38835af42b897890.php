<?php

/* armasapoyo/show.html.twig */
class __TwigTemplate_61e86bbce49f584732db2f37914d920c7c534d49186dea0047e8f54b5434e143 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasapoyo/show.html.twig", 1);
        $this->blocks = array(
            'datosShowApoyo' => array($this, 'block_datosShowApoyo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee4c62a89e0da45ae80a7fe5593b9ad63fb47ae5ef9e5c4ddc448ef61dab26db = $this->env->getExtension("native_profiler");
        $__internal_ee4c62a89e0da45ae80a7fe5593b9ad63fb47ae5ef9e5c4ddc448ef61dab26db->enter($__internal_ee4c62a89e0da45ae80a7fe5593b9ad63fb47ae5ef9e5c4ddc448ef61dab26db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasapoyo/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ee4c62a89e0da45ae80a7fe5593b9ad63fb47ae5ef9e5c4ddc448ef61dab26db->leave($__internal_ee4c62a89e0da45ae80a7fe5593b9ad63fb47ae5ef9e5c4ddc448ef61dab26db_prof);

    }

    // line 3
    public function block_datosShowApoyo($context, array $blocks = array())
    {
        $__internal_d68b37b1e22f3818cba9bb0bc390e055e9065f8f07a5d7317e7596ec5aa5ae99 = $this->env->getExtension("native_profiler");
        $__internal_d68b37b1e22f3818cba9bb0bc390e055e9065f8f07a5d7317e7596ec5aa5ae99->enter($__internal_d68b37b1e22f3818cba9bb0bc390e055e9065f8f07a5d7317e7596ec5aa5ae99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowApoyo"));

        // line 4
        echo "    <h1>ArmasApoyo</h1>

    <table>
        <tbody>
            <tr>
                <th>Arma</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasApoyo"]) ? $context["armasApoyo"] : $this->getContext($context, "armasApoyo")), "arma", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dmg</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasApoyo"]) ? $context["armasApoyo"] : $this->getContext($context, "armasApoyo")), "dmg", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Cargador</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasApoyo"]) ? $context["armasApoyo"] : $this->getContext($context, "armasApoyo")), "cargador", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Id</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasApoyo"]) ? $context["armasApoyo"] : $this->getContext($context, "armasApoyo")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("armasapoyo_index");
        echo "\">Volver a la lista de armas del Apoyo</a>
        </li>
        <li>
            <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasapoyo_edit", array("id" => $this->getAttribute((isset($context["armasApoyo"]) ? $context["armasApoyo"] : $this->getContext($context, "armasApoyo")), "id", array()))), "html", null, true);
        echo "\">Editar</a>
        </li>
        <li>
            ";
        // line 35
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 37
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_d68b37b1e22f3818cba9bb0bc390e055e9065f8f07a5d7317e7596ec5aa5ae99->leave($__internal_d68b37b1e22f3818cba9bb0bc390e055e9065f8f07a5d7317e7596ec5aa5ae99_prof);

    }

    public function getTemplateName()
    {
        return "armasapoyo/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  91 => 35,  85 => 32,  79 => 29,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosShowApoyo %}*/
/*     <h1>ArmasApoyo</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <td>{{ armasApoyo.arma }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dmg</th>*/
/*                 <td>{{ armasApoyo.dmg }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Cargador</th>*/
/*                 <td>{{ armasApoyo.cargador }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ armasApoyo.id }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasapoyo_index') }}">Volver a la lista de armas del Apoyo</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('armasapoyo_edit', { 'id': armasApoyo.id }) }}">Editar</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

/* armasexplorador/new.html.twig */
class __TwigTemplate_87bee217cfd8d72886693fa9767a2bbb0086d3f3e149a4ca5e61874ac797d2a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasexplorador/new.html.twig", 1);
        $this->blocks = array(
            'datosNewExplorador' => array($this, 'block_datosNewExplorador'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1873652fcb2ea3e5f5c33980e0b145fd86d87e63fccdf0e9ef648c4dc64bd20e = $this->env->getExtension("native_profiler");
        $__internal_1873652fcb2ea3e5f5c33980e0b145fd86d87e63fccdf0e9ef648c4dc64bd20e->enter($__internal_1873652fcb2ea3e5f5c33980e0b145fd86d87e63fccdf0e9ef648c4dc64bd20e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasexplorador/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1873652fcb2ea3e5f5c33980e0b145fd86d87e63fccdf0e9ef648c4dc64bd20e->leave($__internal_1873652fcb2ea3e5f5c33980e0b145fd86d87e63fccdf0e9ef648c4dc64bd20e_prof);

    }

    // line 3
    public function block_datosNewExplorador($context, array $blocks = array())
    {
        $__internal_2765fe49d5f58dba4679e17d2f0a4cefa29b577d6e74d2f6a227e3fba959bff6 = $this->env->getExtension("native_profiler");
        $__internal_2765fe49d5f58dba4679e17d2f0a4cefa29b577d6e74d2f6a227e3fba959bff6->enter($__internal_2765fe49d5f58dba4679e17d2f0a4cefa29b577d6e74d2f6a227e3fba959bff6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewExplorador"));

        // line 4
        echo "    <h1>Añadir arma al Explorador</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Añadir\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasexplorador_index");
        echo "\">Volver a la lista de las armas del Explorador</a>
        </li>
    </ul>
";
        
        $__internal_2765fe49d5f58dba4679e17d2f0a4cefa29b577d6e74d2f6a227e3fba959bff6->leave($__internal_2765fe49d5f58dba4679e17d2f0a4cefa29b577d6e74d2f6a227e3fba959bff6_prof);

    }

    public function getTemplateName()
    {
        return "armasexplorador/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosNewExplorador %}*/
/*     <h1>Añadir arma al Explorador</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Añadir" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasexplorador_index') }}">Volver a la lista de las armas del Explorador</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

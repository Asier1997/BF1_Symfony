<?php

/* armasexplorador/index.html.twig */
class __TwigTemplate_b08da4ddcd87ec144e4d63776c5c76d98e4f573a3a32ee37d6c53ab871c27aa8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasexplorador/index.html.twig", 1);
        $this->blocks = array(
            'datosIndexExplorador' => array($this, 'block_datosIndexExplorador'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2205cef9552e63195d27b7e65ba6882f0a1d20484085db32ec6088ffe3d8b5a0 = $this->env->getExtension("native_profiler");
        $__internal_2205cef9552e63195d27b7e65ba6882f0a1d20484085db32ec6088ffe3d8b5a0->enter($__internal_2205cef9552e63195d27b7e65ba6882f0a1d20484085db32ec6088ffe3d8b5a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasexplorador/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2205cef9552e63195d27b7e65ba6882f0a1d20484085db32ec6088ffe3d8b5a0->leave($__internal_2205cef9552e63195d27b7e65ba6882f0a1d20484085db32ec6088ffe3d8b5a0_prof);

    }

    // line 3
    public function block_datosIndexExplorador($context, array $blocks = array())
    {
        $__internal_930aaa728b65fa2ce862b1eb595770226c0a1ea2a58dab639453a5a39a3f2338 = $this->env->getExtension("native_profiler");
        $__internal_930aaa728b65fa2ce862b1eb595770226c0a1ea2a58dab639453a5a39a3f2338->enter($__internal_930aaa728b65fa2ce862b1eb595770226c0a1ea2a58dab639453a5a39a3f2338_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosIndexExplorador"));

        // line 4
        echo "    <h1>Lista de armas del Explorador</h1>

    <table border=\"solid black 2px\">
        <thead>
            <tr>
                <th>Arma</th>
                <th>Dmg</th>
                <th>Cargador</th>
                <th>Id</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["armasExploradors"]) ? $context["armasExploradors"] : $this->getContext($context, "armasExploradors")));
        foreach ($context['_seq'] as $context["_key"] => $context["armasExplorador"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasExplorador"], "arma", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasExplorador"], "dmg", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasExplorador"], "cargador", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["armasExplorador"], "id", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasexplorador_show", array("id" => $this->getAttribute($context["armasExplorador"], "id", array()))), "html", null, true);
            echo "\">Mostrar</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasexplorador_edit", array("id" => $this->getAttribute($context["armasExplorador"], "id", array()))), "html", null, true);
            echo "\">Editar</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['armasExplorador'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 40
        echo $this->env->getExtension('routing')->getPath("armasexplorador_new");
        echo "\">Añadir nueva arma al Explorador</a>
        </li>
    </ul>
";
        
        $__internal_930aaa728b65fa2ce862b1eb595770226c0a1ea2a58dab639453a5a39a3f2338->leave($__internal_930aaa728b65fa2ce862b1eb595770226c0a1ea2a58dab639453a5a39a3f2338_prof);

    }

    public function getTemplateName()
    {
        return "armasexplorador/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 40,  99 => 35,  87 => 29,  81 => 26,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  59 => 18,  55 => 17,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosIndexExplorador %}*/
/*     <h1>Lista de armas del Explorador</h1>*/
/* */
/*     <table border="solid black 2px">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <th>Dmg</th>*/
/*                 <th>Cargador</th>*/
/*                 <th>Id</th>*/
/*                 <th>Acciones</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for armasExplorador in armasExploradors %}*/
/*             <tr>*/
/*                 <td>{{ armasExplorador.arma }}</td>*/
/*                 <td>{{ armasExplorador.dmg }}</td>*/
/*                 <td>{{ armasExplorador.cargador }}</td>*/
/*                 <td>{{ armasExplorador.id }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('armasexplorador_show', { 'id': armasExplorador.id }) }}">Mostrar</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('armasexplorador_edit', { 'id': armasExplorador.id }) }}">Editar</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasexplorador_new') }}">Añadir nueva arma al Explorador</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

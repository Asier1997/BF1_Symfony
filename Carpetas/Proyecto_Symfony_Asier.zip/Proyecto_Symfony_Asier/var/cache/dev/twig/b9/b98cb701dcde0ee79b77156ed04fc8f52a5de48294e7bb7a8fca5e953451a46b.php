<?php

/* armasasalto/new.html.twig */
class __TwigTemplate_f3cab21813e1079e29da020453f6ad6f6ccaace7ba56f2d377f9ca627be3f9db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasasalto/new.html.twig", 1);
        $this->blocks = array(
            'datosNewAsalto' => array($this, 'block_datosNewAsalto'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c4485a1de4f2b3235e10ba13a33f680dd798db7968159675d4b620702399b00 = $this->env->getExtension("native_profiler");
        $__internal_6c4485a1de4f2b3235e10ba13a33f680dd798db7968159675d4b620702399b00->enter($__internal_6c4485a1de4f2b3235e10ba13a33f680dd798db7968159675d4b620702399b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasasalto/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6c4485a1de4f2b3235e10ba13a33f680dd798db7968159675d4b620702399b00->leave($__internal_6c4485a1de4f2b3235e10ba13a33f680dd798db7968159675d4b620702399b00_prof);

    }

    // line 3
    public function block_datosNewAsalto($context, array $blocks = array())
    {
        $__internal_d73b0a7984cdef1a1f6aff3a93b8dcdd6b7c40364ac5ad97dc66eccc33659a03 = $this->env->getExtension("native_profiler");
        $__internal_d73b0a7984cdef1a1f6aff3a93b8dcdd6b7c40364ac5ad97dc66eccc33659a03->enter($__internal_d73b0a7984cdef1a1f6aff3a93b8dcdd6b7c40364ac5ad97dc66eccc33659a03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewAsalto"));

        // line 4
        echo "    <h1>Añadir arma al Asalto</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Añadir\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasasalto_index");
        echo "\">Volver a la lista de las armas del Asalto</a>
        </li>
    </ul>
";
        
        $__internal_d73b0a7984cdef1a1f6aff3a93b8dcdd6b7c40364ac5ad97dc66eccc33659a03->leave($__internal_d73b0a7984cdef1a1f6aff3a93b8dcdd6b7c40364ac5ad97dc66eccc33659a03_prof);

    }

    public function getTemplateName()
    {
        return "armasasalto/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosNewAsalto %}*/
/*     <h1>Añadir arma al Asalto</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Añadir" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasasalto_index') }}">Volver a la lista de las armas del Asalto</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

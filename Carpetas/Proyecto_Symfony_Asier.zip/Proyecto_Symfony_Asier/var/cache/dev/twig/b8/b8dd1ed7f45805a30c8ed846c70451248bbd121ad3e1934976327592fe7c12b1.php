<?php

/* Apoyo/Apoyo.html.twig */
class __TwigTemplate_a18dc7ea94a84eeb97630ae0012c2d3c0c0799a228493c342c432480ff076da9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Apoyo/Apoyo.html.twig", 1);
        $this->blocks = array(
            'textoApoyo' => array($this, 'block_textoApoyo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_635c93e73629dcb72f7d05dc7753d468f4626e073b2a6b818c2668a909d5c85b = $this->env->getExtension("native_profiler");
        $__internal_635c93e73629dcb72f7d05dc7753d468f4626e073b2a6b818c2668a909d5c85b->enter($__internal_635c93e73629dcb72f7d05dc7753d468f4626e073b2a6b818c2668a909d5c85b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Apoyo/Apoyo.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_635c93e73629dcb72f7d05dc7753d468f4626e073b2a6b818c2668a909d5c85b->leave($__internal_635c93e73629dcb72f7d05dc7753d468f4626e073b2a6b818c2668a909d5c85b_prof);

    }

    // line 3
    public function block_textoApoyo($context, array $blocks = array())
    {
        $__internal_58bb6d9c1f0d99aebb9fb62ca46853e75a738f2f16076dc63aa3912bcea81748 = $this->env->getExtension("native_profiler");
        $__internal_58bb6d9c1f0d99aebb9fb62ca46853e75a738f2f16076dc63aa3912bcea81748->enter($__internal_58bb6d9c1f0d99aebb9fb62ca46853e75a738f2f16076dc63aa3912bcea81748_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoApoyo"));

        // line 4
        echo "<br>Bienvenido a la guia del apoyo.</br>
<br>El Apoyo tiene ametralladoras ligeras que son muy efectivas en contener grupos de enemigos, y más aún si están a medio alcance. La función principal</br>
<br>de esta clase, es la de proporcionar munición y ayudar a la hora de destruir tanques enemigos. Para esto, el Apoyo dispone de cajas de munición y cargas</br>
<br>antitanque.</br>
<br></br>
<br>La estrategia que deberías llevar, es la de intentar estar cerca de de los asalto aliados, que son los que más munición suelen necesitar, ya que gastaran</br>
<br>sus dispositivos más a menudo que los demás. Con tu ametralladora podras ofrecer apoyo cercano a los soldados de asalto que necesiten acercarse para</br>
<br>hacer daño</br>
<img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Apoyo_edit.jpg"), "html", null, true);
        echo "\"/>
";
        
        $__internal_58bb6d9c1f0d99aebb9fb62ca46853e75a738f2f16076dc63aa3912bcea81748->leave($__internal_58bb6d9c1f0d99aebb9fb62ca46853e75a738f2f16076dc63aa3912bcea81748_prof);

    }

    public function getTemplateName()
    {
        return "Apoyo/Apoyo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 12,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoApoyo %}*/
/* <br>Bienvenido a la guia del apoyo.</br>*/
/* <br>El Apoyo tiene ametralladoras ligeras que son muy efectivas en contener grupos de enemigos, y más aún si están a medio alcance. La función principal</br>*/
/* <br>de esta clase, es la de proporcionar munición y ayudar a la hora de destruir tanques enemigos. Para esto, el Apoyo dispone de cajas de munición y cargas</br>*/
/* <br>antitanque.</br>*/
/* <br></br>*/
/* <br>La estrategia que deberías llevar, es la de intentar estar cerca de de los asalto aliados, que son los que más munición suelen necesitar, ya que gastaran</br>*/
/* <br>sus dispositivos más a menudo que los demás. Con tu ametralladora podras ofrecer apoyo cercano a los soldados de asalto que necesiten acercarse para</br>*/
/* <br>hacer daño</br>*/
/* <img src="{{asset('build/images/Apoyo_edit.jpg')}}"/>*/
/* {% endblock %}*/

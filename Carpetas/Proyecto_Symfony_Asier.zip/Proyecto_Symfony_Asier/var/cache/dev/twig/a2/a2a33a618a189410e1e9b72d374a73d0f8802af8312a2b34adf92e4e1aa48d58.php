<?php

/* armasexplorador/show.html.twig */
class __TwigTemplate_e4c0c0c0649c58090e97df6f2576301955f079a4f8ee1d7c1b267fa5c88a7d0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasexplorador/show.html.twig", 1);
        $this->blocks = array(
            'datosShowExplorador' => array($this, 'block_datosShowExplorador'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7fbd69ddecb27b2040373dde2e8e96a8c9290d869d7594e1dbb16bdc3768b085 = $this->env->getExtension("native_profiler");
        $__internal_7fbd69ddecb27b2040373dde2e8e96a8c9290d869d7594e1dbb16bdc3768b085->enter($__internal_7fbd69ddecb27b2040373dde2e8e96a8c9290d869d7594e1dbb16bdc3768b085_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasexplorador/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7fbd69ddecb27b2040373dde2e8e96a8c9290d869d7594e1dbb16bdc3768b085->leave($__internal_7fbd69ddecb27b2040373dde2e8e96a8c9290d869d7594e1dbb16bdc3768b085_prof);

    }

    // line 3
    public function block_datosShowExplorador($context, array $blocks = array())
    {
        $__internal_47fbc41bf67130d2da5cfc3f078b3e7bcd817d7d195012d45cc1e2d19f79f29f = $this->env->getExtension("native_profiler");
        $__internal_47fbc41bf67130d2da5cfc3f078b3e7bcd817d7d195012d45cc1e2d19f79f29f->enter($__internal_47fbc41bf67130d2da5cfc3f078b3e7bcd817d7d195012d45cc1e2d19f79f29f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowExplorador"));

        // line 4
        echo "    <h1>Mostrando arma del Explorador</h1>

    <table>
        <tbody>
            <tr>
                <th>Arma</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasExplorador"]) ? $context["armasExplorador"] : $this->getContext($context, "armasExplorador")), "arma", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dmg</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasExplorador"]) ? $context["armasExplorador"] : $this->getContext($context, "armasExplorador")), "dmg", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Cargador</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasExplorador"]) ? $context["armasExplorador"] : $this->getContext($context, "armasExplorador")), "cargador", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Id</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasExplorador"]) ? $context["armasExplorador"] : $this->getContext($context, "armasExplorador")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("armasexplorador_index");
        echo "\">Volver a la lista de las armas del Explorador</a>
        </li>
        <li>
            <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasexplorador_edit", array("id" => $this->getAttribute((isset($context["armasExplorador"]) ? $context["armasExplorador"] : $this->getContext($context, "armasExplorador")), "id", array()))), "html", null, true);
        echo "\">Editar</a>
        </li>
        <li>
            ";
        // line 35
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 37
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_47fbc41bf67130d2da5cfc3f078b3e7bcd817d7d195012d45cc1e2d19f79f29f->leave($__internal_47fbc41bf67130d2da5cfc3f078b3e7bcd817d7d195012d45cc1e2d19f79f29f_prof);

    }

    public function getTemplateName()
    {
        return "armasexplorador/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  91 => 35,  85 => 32,  79 => 29,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosShowExplorador %}*/
/*     <h1>Mostrando arma del Explorador</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <td>{{ armasExplorador.arma }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dmg</th>*/
/*                 <td>{{ armasExplorador.dmg }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Cargador</th>*/
/*                 <td>{{ armasExplorador.cargador }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ armasExplorador.id }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasexplorador_index') }}">Volver a la lista de las armas del Explorador</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('armasexplorador_edit', { 'id': armasExplorador.id }) }}">Editar</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

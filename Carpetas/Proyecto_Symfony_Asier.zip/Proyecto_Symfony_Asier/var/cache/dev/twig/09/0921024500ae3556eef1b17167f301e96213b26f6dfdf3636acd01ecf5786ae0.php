<?php

/* armasmedico/new.html.twig */
class __TwigTemplate_ff8aef1783422e78376074ae1c43db456e69599bc24b23c4f4ac3e290c8e6dda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasmedico/new.html.twig", 1);
        $this->blocks = array(
            'datosNewMedico' => array($this, 'block_datosNewMedico'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b0a7b70b639d3268b40a06035fb04f40783ce632c6585f82b19134d8eea4bb2 = $this->env->getExtension("native_profiler");
        $__internal_0b0a7b70b639d3268b40a06035fb04f40783ce632c6585f82b19134d8eea4bb2->enter($__internal_0b0a7b70b639d3268b40a06035fb04f40783ce632c6585f82b19134d8eea4bb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasmedico/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b0a7b70b639d3268b40a06035fb04f40783ce632c6585f82b19134d8eea4bb2->leave($__internal_0b0a7b70b639d3268b40a06035fb04f40783ce632c6585f82b19134d8eea4bb2_prof);

    }

    // line 3
    public function block_datosNewMedico($context, array $blocks = array())
    {
        $__internal_a99208df57ee042fe83ea34d1e314b81348c63f1853abae5b491c6a9447e3a0b = $this->env->getExtension("native_profiler");
        $__internal_a99208df57ee042fe83ea34d1e314b81348c63f1853abae5b491c6a9447e3a0b->enter($__internal_a99208df57ee042fe83ea34d1e314b81348c63f1853abae5b491c6a9447e3a0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosNewMedico"));

        // line 4
        echo "    <h1>Añadir arma al Médico</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Añadir\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasmedico_index");
        echo "\">Volver a la lista de armas del Médico</a>
        </li>
    </ul>
";
        
        $__internal_a99208df57ee042fe83ea34d1e314b81348c63f1853abae5b491c6a9447e3a0b->leave($__internal_a99208df57ee042fe83ea34d1e314b81348c63f1853abae5b491c6a9447e3a0b_prof);

    }

    public function getTemplateName()
    {
        return "armasmedico/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosNewMedico %}*/
/*     <h1>Añadir arma al Médico</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Añadir" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasmedico_index') }}">Volver a la lista de armas del Médico</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

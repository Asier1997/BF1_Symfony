<?php

/* Medico/Medico.html.twig */
class __TwigTemplate_47cf7df9fc4c7690efd57fbca8eb216cba9c5f27e1acf0f3140063029cd4abda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "Medico/Medico.html.twig", 1);
        $this->blocks = array(
            'textoMedico' => array($this, 'block_textoMedico'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d71e9973f1d4d13a2a4d42ef0922d4c7780717d528a14ab52f381b396839c99e = $this->env->getExtension("native_profiler");
        $__internal_d71e9973f1d4d13a2a4d42ef0922d4c7780717d528a14ab52f381b396839c99e->enter($__internal_d71e9973f1d4d13a2a4d42ef0922d4c7780717d528a14ab52f381b396839c99e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Medico/Medico.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d71e9973f1d4d13a2a4d42ef0922d4c7780717d528a14ab52f381b396839c99e->leave($__internal_d71e9973f1d4d13a2a4d42ef0922d4c7780717d528a14ab52f381b396839c99e_prof);

    }

    // line 3
    public function block_textoMedico($context, array $blocks = array())
    {
        $__internal_76ca0949d4ac997ec8646821182aae492f8470d54397579afba45f10ba74369a = $this->env->getExtension("native_profiler");
        $__internal_76ca0949d4ac997ec8646821182aae492f8470d54397579afba45f10ba74369a->enter($__internal_76ca0949d4ac997ec8646821182aae492f8470d54397579afba45f10ba74369a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textoMedico"));

        // line 4
        echo "<br>En esta página encontraras la guía de la clase del médico</br>
<br>El medico dispone de armas de medio-largo alcance, fusiles semiautomáticos capaces de eliminar a enemigos a distancias considerables. La función principal del médico es la de</br>
<br>curar y revivir a los compañeros caídos, mediante el uso de jeringuillas y botiquines. Aunque puede cambiar sus dispositivos para ser más agresivo. Por ejemplo cambiarse la jeringuilla</br>
<br>por un lanzagranadas.</br>
<br></br>
<br>Si quieres jugar como un verdadero médico,  deberías llevar siempre la jeringuilla(para curar a los compañeros caídos) y el botiquín(para restaurar salud más rápido). Tu estrategia debería</br>
<br>consistir en intentar mantenerte a una distancia segura y curar o revivir a tus aliados, pero tampoco estas indefenso. Tu rifle semiautomático es una muy buena arma a medias-largas</br>
<br>y casi ninguna clase podrá hacerte frente.</br>
<br></br>
<br>Si quieres jugar de forma más agresiva, deberías ir con el lanzagranadas(para que los enemigos tenga que salir de las coberturas) y el botiquín. Con estos dispositivos deberías ser capaz</br>
<br>de hacer frente a cualquier clase a medias distancias, así que ten cuidado a cortas distancias. Los asaltos serán muy peligrosos a cortas distancias, así que anda con cuidado.</br>

<img src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("build/images/Medico_edit.jpg"), "html", null, true);
        echo "\"/>
";
        
        $__internal_76ca0949d4ac997ec8646821182aae492f8470d54397579afba45f10ba74369a->leave($__internal_76ca0949d4ac997ec8646821182aae492f8470d54397579afba45f10ba74369a_prof);

    }

    public function getTemplateName()
    {
        return "Medico/Medico.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block textoMedico %}*/
/* <br>En esta página encontraras la guía de la clase del médico</br>*/
/* <br>El medico dispone de armas de medio-largo alcance, fusiles semiautomáticos capaces de eliminar a enemigos a distancias considerables. La función principal del médico es la de</br>*/
/* <br>curar y revivir a los compañeros caídos, mediante el uso de jeringuillas y botiquines. Aunque puede cambiar sus dispositivos para ser más agresivo. Por ejemplo cambiarse la jeringuilla</br>*/
/* <br>por un lanzagranadas.</br>*/
/* <br></br>*/
/* <br>Si quieres jugar como un verdadero médico,  deberías llevar siempre la jeringuilla(para curar a los compañeros caídos) y el botiquín(para restaurar salud más rápido). Tu estrategia debería</br>*/
/* <br>consistir en intentar mantenerte a una distancia segura y curar o revivir a tus aliados, pero tampoco estas indefenso. Tu rifle semiautomático es una muy buena arma a medias-largas</br>*/
/* <br>y casi ninguna clase podrá hacerte frente.</br>*/
/* <br></br>*/
/* <br>Si quieres jugar de forma más agresiva, deberías ir con el lanzagranadas(para que los enemigos tenga que salir de las coberturas) y el botiquín. Con estos dispositivos deberías ser capaz</br>*/
/* <br>de hacer frente a cualquier clase a medias distancias, así que ten cuidado a cortas distancias. Los asaltos serán muy peligrosos a cortas distancias, así que anda con cuidado.</br>*/
/* */
/* <img src="{{asset('build/images/Medico_edit.jpg')}}"/>*/
/* {% endblock %}*/

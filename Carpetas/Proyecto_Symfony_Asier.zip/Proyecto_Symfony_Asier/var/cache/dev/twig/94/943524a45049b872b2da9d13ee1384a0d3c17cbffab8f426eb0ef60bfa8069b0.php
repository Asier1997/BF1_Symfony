<?php

/* armasexplorador/edit.html.twig */
class __TwigTemplate_8ef65d78a2ba066e7fdbe8d46fcf4856f3c70d2ab8c9a091ffc8dfd09ba05e21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasexplorador/edit.html.twig", 1);
        $this->blocks = array(
            'datosEditExplorador' => array($this, 'block_datosEditExplorador'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4d4a5ac65a0c024fe1c8ee4e12374aff425d60dbd313686044a0c8864a8a208 = $this->env->getExtension("native_profiler");
        $__internal_b4d4a5ac65a0c024fe1c8ee4e12374aff425d60dbd313686044a0c8864a8a208->enter($__internal_b4d4a5ac65a0c024fe1c8ee4e12374aff425d60dbd313686044a0c8864a8a208_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasexplorador/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4d4a5ac65a0c024fe1c8ee4e12374aff425d60dbd313686044a0c8864a8a208->leave($__internal_b4d4a5ac65a0c024fe1c8ee4e12374aff425d60dbd313686044a0c8864a8a208_prof);

    }

    // line 3
    public function block_datosEditExplorador($context, array $blocks = array())
    {
        $__internal_1961d21e115017a6042c09cd24ef02868f0940ed936cb77337ddb9320774ddc6 = $this->env->getExtension("native_profiler");
        $__internal_1961d21e115017a6042c09cd24ef02868f0940ed936cb77337ddb9320774ddc6->enter($__internal_1961d21e115017a6042c09cd24ef02868f0940ed936cb77337ddb9320774ddc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosEditExplorador"));

        // line 4
        echo "    <h1>Editar arma del Explorador</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Editar\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("armasexplorador_index");
        echo "\">Volver a la lista de las armas del Explorador</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_1961d21e115017a6042c09cd24ef02868f0940ed936cb77337ddb9320774ddc6->leave($__internal_1961d21e115017a6042c09cd24ef02868f0940ed936cb77337ddb9320774ddc6_prof);

    }

    public function getTemplateName()
    {
        return "armasexplorador/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosEditExplorador %}*/
/*     <h1>Editar arma del Explorador</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Editar" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasexplorador_index') }}">Volver a la lista de las armas del Explorador</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

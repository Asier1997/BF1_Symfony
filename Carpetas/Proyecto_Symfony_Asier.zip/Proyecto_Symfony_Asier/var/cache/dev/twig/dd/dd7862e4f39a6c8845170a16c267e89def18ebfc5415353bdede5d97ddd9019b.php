<?php

/* armasasalto/show.html.twig */
class __TwigTemplate_a93c913823c234c159307066566cd58dc5ad274995fa23c2ae89de5a8fe72892 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasasalto/show.html.twig", 1);
        $this->blocks = array(
            'datosShowAsalto' => array($this, 'block_datosShowAsalto'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ccd9b4598ea7107518c838750878aa0ca6b3bb9b5de8739d12fd0c7d009bdda9 = $this->env->getExtension("native_profiler");
        $__internal_ccd9b4598ea7107518c838750878aa0ca6b3bb9b5de8739d12fd0c7d009bdda9->enter($__internal_ccd9b4598ea7107518c838750878aa0ca6b3bb9b5de8739d12fd0c7d009bdda9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasasalto/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ccd9b4598ea7107518c838750878aa0ca6b3bb9b5de8739d12fd0c7d009bdda9->leave($__internal_ccd9b4598ea7107518c838750878aa0ca6b3bb9b5de8739d12fd0c7d009bdda9_prof);

    }

    // line 3
    public function block_datosShowAsalto($context, array $blocks = array())
    {
        $__internal_59c031a3287295fb6bcb916a317ec399600b4fe01e474785014d25989f23cc6d = $this->env->getExtension("native_profiler");
        $__internal_59c031a3287295fb6bcb916a317ec399600b4fe01e474785014d25989f23cc6d->enter($__internal_59c031a3287295fb6bcb916a317ec399600b4fe01e474785014d25989f23cc6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowAsalto"));

        // line 4
        echo "    <h1>Mostrando arma del Asalto</h1>

    <table>
        <tbody>
            <tr>
                <th>Arma</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasAsalto"]) ? $context["armasAsalto"] : $this->getContext($context, "armasAsalto")), "arma", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dmg</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasAsalto"]) ? $context["armasAsalto"] : $this->getContext($context, "armasAsalto")), "dmg", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Cargador</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasAsalto"]) ? $context["armasAsalto"] : $this->getContext($context, "armasAsalto")), "cargador", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Id</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasAsalto"]) ? $context["armasAsalto"] : $this->getContext($context, "armasAsalto")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("armasasalto_index");
        echo "\">Volver a la lista de las armas del Asalto</a>
        </li>
        <li>
            <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasasalto_edit", array("id" => $this->getAttribute((isset($context["armasAsalto"]) ? $context["armasAsalto"] : $this->getContext($context, "armasAsalto")), "id", array()))), "html", null, true);
        echo "\">Editar</a>
        </li>
        <li>
            ";
        // line 35
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 37
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_59c031a3287295fb6bcb916a317ec399600b4fe01e474785014d25989f23cc6d->leave($__internal_59c031a3287295fb6bcb916a317ec399600b4fe01e474785014d25989f23cc6d_prof);

    }

    public function getTemplateName()
    {
        return "armasasalto/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  91 => 35,  85 => 32,  79 => 29,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosShowAsalto %}*/
/*     <h1>Mostrando arma del Asalto</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <td>{{ armasAsalto.arma }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dmg</th>*/
/*                 <td>{{ armasAsalto.dmg }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Cargador</th>*/
/*                 <td>{{ armasAsalto.cargador }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ armasAsalto.id }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasasalto_index') }}">Volver a la lista de las armas del Asalto</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('armasasalto_edit', { 'id': armasAsalto.id }) }}">Editar</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

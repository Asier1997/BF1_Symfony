<?php

/* armasmedico/show.html.twig */
class __TwigTemplate_2812a561c7e141a571dd5e1fc3097e1bacb0c9d2cf608056ff72f519bd7adec3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("cabecera.html.twig", "armasmedico/show.html.twig", 1);
        $this->blocks = array(
            'datosShowMedico' => array($this, 'block_datosShowMedico'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "cabecera.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9eaeac09850147fb1ae15a3e3a980e68e1249c701abbb40332a2a9b8b87baf2 = $this->env->getExtension("native_profiler");
        $__internal_e9eaeac09850147fb1ae15a3e3a980e68e1249c701abbb40332a2a9b8b87baf2->enter($__internal_e9eaeac09850147fb1ae15a3e3a980e68e1249c701abbb40332a2a9b8b87baf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "armasmedico/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e9eaeac09850147fb1ae15a3e3a980e68e1249c701abbb40332a2a9b8b87baf2->leave($__internal_e9eaeac09850147fb1ae15a3e3a980e68e1249c701abbb40332a2a9b8b87baf2_prof);

    }

    // line 3
    public function block_datosShowMedico($context, array $blocks = array())
    {
        $__internal_509e16b800eda228c25fb13973c054219f38a31c4aeab23805bd6b4450a7baf2 = $this->env->getExtension("native_profiler");
        $__internal_509e16b800eda228c25fb13973c054219f38a31c4aeab23805bd6b4450a7baf2->enter($__internal_509e16b800eda228c25fb13973c054219f38a31c4aeab23805bd6b4450a7baf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datosShowMedico"));

        // line 4
        echo "    <h1>Mostrando arma del Médico</h1>

    <table>
        <tbody>
            <tr>
                <th>Arma</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasMedico"]) ? $context["armasMedico"] : $this->getContext($context, "armasMedico")), "arma", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dmg</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasMedico"]) ? $context["armasMedico"] : $this->getContext($context, "armasMedico")), "dmg", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Cargador</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasMedico"]) ? $context["armasMedico"] : $this->getContext($context, "armasMedico")), "cargador", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Id</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["armasMedico"]) ? $context["armasMedico"] : $this->getContext($context, "armasMedico")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 29
        echo $this->env->getExtension('routing')->getPath("armasmedico_index");
        echo "\">Volver a la lista de armas del Médico</a>
        </li>
        <li>
            <a href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("armasmedico_edit", array("id" => $this->getAttribute((isset($context["armasMedico"]) ? $context["armasMedico"] : $this->getContext($context, "armasMedico")), "id", array()))), "html", null, true);
        echo "\">Editar</a>
        </li>
        <li>
            ";
        // line 35
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Eliminar\">
            ";
        // line 37
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_509e16b800eda228c25fb13973c054219f38a31c4aeab23805bd6b4450a7baf2->leave($__internal_509e16b800eda228c25fb13973c054219f38a31c4aeab23805bd6b4450a7baf2_prof);

    }

    public function getTemplateName()
    {
        return "armasmedico/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 37,  91 => 35,  85 => 32,  79 => 29,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'cabecera.html.twig' %}*/
/* */
/* {% block datosShowMedico %}*/
/*     <h1>Mostrando arma del Médico</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Arma</th>*/
/*                 <td>{{ armasMedico.arma }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dmg</th>*/
/*                 <td>{{ armasMedico.dmg }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Cargador</th>*/
/*                 <td>{{ armasMedico.cargador }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ armasMedico.id }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('armasmedico_index') }}">Volver a la lista de armas del Médico</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('armasmedico_edit', { 'id': armasMedico.id }) }}">Editar</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Eliminar">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */

<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/armas')) {
            if (0 === strpos($pathinfo, '/armasa')) {
                if (0 === strpos($pathinfo, '/armasapoyo')) {
                    // armasapoyo_index
                    if (rtrim($pathinfo, '/') === '/armasapoyo') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_armasapoyo_index;
                        }

                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'armasapoyo_index');
                        }

                        return array (  '_controller' => 'AppBundle\\Controller\\ArmasApoyoController::indexAction',  '_route' => 'armasapoyo_index',);
                    }
                    not_armasapoyo_index:

                    // armasapoyo_new
                    if ($pathinfo === '/armasapoyo/new') {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_armasapoyo_new;
                        }

                        return array (  '_controller' => 'AppBundle\\Controller\\ArmasApoyoController::newAction',  '_route' => 'armasapoyo_new',);
                    }
                    not_armasapoyo_new:

                    // armasapoyo_show
                    if (preg_match('#^/armasapoyo/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_armasapoyo_show;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasapoyo_show')), array (  '_controller' => 'AppBundle\\Controller\\ArmasApoyoController::showAction',));
                    }
                    not_armasapoyo_show:

                    // armasapoyo_edit
                    if (preg_match('#^/armasapoyo/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_armasapoyo_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasapoyo_edit')), array (  '_controller' => 'AppBundle\\Controller\\ArmasApoyoController::editAction',));
                    }
                    not_armasapoyo_edit:

                    // armasapoyo_delete
                    if (preg_match('#^/armasapoyo/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_armasapoyo_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasapoyo_delete')), array (  '_controller' => 'AppBundle\\Controller\\ArmasApoyoController::deleteAction',));
                    }
                    not_armasapoyo_delete:

                }

                if (0 === strpos($pathinfo, '/armasasalto')) {
                    // armasasalto_index
                    if (rtrim($pathinfo, '/') === '/armasasalto') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_armasasalto_index;
                        }

                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'armasasalto_index');
                        }

                        return array (  '_controller' => 'AppBundle\\Controller\\ArmasAsaltoController::indexAction',  '_route' => 'armasasalto_index',);
                    }
                    not_armasasalto_index:

                    // armasasalto_new
                    if ($pathinfo === '/armasasalto/new') {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_armasasalto_new;
                        }

                        return array (  '_controller' => 'AppBundle\\Controller\\ArmasAsaltoController::newAction',  '_route' => 'armasasalto_new',);
                    }
                    not_armasasalto_new:

                    // armasasalto_show
                    if (preg_match('#^/armasasalto/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_armasasalto_show;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasasalto_show')), array (  '_controller' => 'AppBundle\\Controller\\ArmasAsaltoController::showAction',));
                    }
                    not_armasasalto_show:

                    // armasasalto_edit
                    if (preg_match('#^/armasasalto/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                            goto not_armasasalto_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasasalto_edit')), array (  '_controller' => 'AppBundle\\Controller\\ArmasAsaltoController::editAction',));
                    }
                    not_armasasalto_edit:

                    // armasasalto_delete
                    if (preg_match('#^/armasasalto/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_armasasalto_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasasalto_delete')), array (  '_controller' => 'AppBundle\\Controller\\ArmasAsaltoController::deleteAction',));
                    }
                    not_armasasalto_delete:

                }

            }

            if (0 === strpos($pathinfo, '/armasexplorador')) {
                // armasexplorador_index
                if (rtrim($pathinfo, '/') === '/armasexplorador') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_armasexplorador_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'armasexplorador_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ArmasExploradorController::indexAction',  '_route' => 'armasexplorador_index',);
                }
                not_armasexplorador_index:

                // armasexplorador_new
                if ($pathinfo === '/armasexplorador/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_armasexplorador_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ArmasExploradorController::newAction',  '_route' => 'armasexplorador_new',);
                }
                not_armasexplorador_new:

                // armasexplorador_show
                if (preg_match('#^/armasexplorador/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_armasexplorador_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasexplorador_show')), array (  '_controller' => 'AppBundle\\Controller\\ArmasExploradorController::showAction',));
                }
                not_armasexplorador_show:

                // armasexplorador_edit
                if (preg_match('#^/armasexplorador/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_armasexplorador_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasexplorador_edit')), array (  '_controller' => 'AppBundle\\Controller\\ArmasExploradorController::editAction',));
                }
                not_armasexplorador_edit:

                // armasexplorador_delete
                if (preg_match('#^/armasexplorador/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_armasexplorador_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasexplorador_delete')), array (  '_controller' => 'AppBundle\\Controller\\ArmasExploradorController::deleteAction',));
                }
                not_armasexplorador_delete:

            }

            if (0 === strpos($pathinfo, '/armasmedico')) {
                // armasmedico_index
                if (rtrim($pathinfo, '/') === '/armasmedico') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_armasmedico_index;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'armasmedico_index');
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ArmasMedicoController::indexAction',  '_route' => 'armasmedico_index',);
                }
                not_armasmedico_index:

                // armasmedico_new
                if ($pathinfo === '/armasmedico/new') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_armasmedico_new;
                    }

                    return array (  '_controller' => 'AppBundle\\Controller\\ArmasMedicoController::newAction',  '_route' => 'armasmedico_new',);
                }
                not_armasmedico_new:

                // armasmedico_show
                if (preg_match('#^/armasmedico/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_armasmedico_show;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasmedico_show')), array (  '_controller' => 'AppBundle\\Controller\\ArmasMedicoController::showAction',));
                }
                not_armasmedico_show:

                // armasmedico_edit
                if (preg_match('#^/armasmedico/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_armasmedico_edit;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasmedico_edit')), array (  '_controller' => 'AppBundle\\Controller\\ArmasMedicoController::editAction',));
                }
                not_armasmedico_edit:

                // armasmedico_delete
                if (preg_match('#^/armasmedico/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_armasmedico_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'armasmedico_delete')), array (  '_controller' => 'AppBundle\\Controller\\ArmasMedicoController::deleteAction',));
                }
                not_armasmedico_delete:

            }

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        // inicio
        if ($pathinfo === '/inicio') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::inicioAction',  '_route' => 'inicio',);
        }

        if (0 === strpos($pathinfo, '/a')) {
            // asalto
            if ($pathinfo === '/asalto') {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::asaltoAction',  '_route' => 'asalto',);
            }

            // apoyo
            if ($pathinfo === '/apoyo') {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::apoyoAction',  '_route' => 'apoyo',);
            }

        }

        // medico
        if ($pathinfo === '/medico') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::medicoAction',  '_route' => 'medico',);
        }

        // explorador
        if ($pathinfo === '/explorador') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::exploradorAction',  '_route' => 'explorador',);
        }

        // vehiculos
        if ($pathinfo === '/vehiculos') {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::vehiculosAction',  '_route' => 'vehiculos',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}

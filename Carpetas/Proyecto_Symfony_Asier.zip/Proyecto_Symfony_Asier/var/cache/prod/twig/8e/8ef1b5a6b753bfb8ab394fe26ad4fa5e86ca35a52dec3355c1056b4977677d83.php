<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_adbf0af74e228e6c6cc65e3438f1bf80ad67808254cf0d007467612f293953f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}

<?php

/* TwigBundle:Exception:error.html.twig */
class __TwigTemplate_21b67f0c75b09934c171a6a6aad30ff6d203ea838cf8bdaefd6771a138abc06e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <title>Vaya! a ocurrido un problema: ";
        // line 5
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : null), "html", null, true);
        echo "</title>
    </head>
    <body>
        <h1>Parece ser que hay algun problema</h1>
        <h2>El servidor a retornado\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : null), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : null), "html", null, true);
        echo "\".</h2>

        <div>
            Algo esta roto. Dejanos saber el error y intentaremos solucionarlo lo antes posible. Lo sentimos por las molestias causadas.
        </div>
    </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 9,  28 => 5,  24 => 4,  19 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="{{ _charset }}" />*/
/*         <title>Vaya! a ocurrido un problema: {{ status_text }}</title>*/
/*     </head>*/
/*     <body>*/
/*         <h1>Parece ser que hay algun problema</h1>*/
/*         <h2>El servidor a retornado"{{ status_code }} {{ status_text }}".</h2>*/
/* */
/*         <div>*/
/*             Algo esta roto. Dejanos saber el error y intentaremos solucionarlo lo antes posible. Lo sentimos por las molestias causadas.*/
/*         </div>*/
/*     </body>*/
/* </html>*/
/* */
